/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
static const char *ng1 = "";
extern char *IEEE_P_1242562249;
static const char *ng3 = "C:/xilinx/14.7/ISE_DS/EDK/hw/XilinxProcessorIPLib/pcores/axi_datamover_v4_02_a/hdl/vhdl/axi_datamover_stbs_set.vhd";

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
char *ieee_p_1242562249_sub_2045698577_1035706684(char *, char *, char *, char *, int );


char *axi_datamover_v4_02_a_a_2433371128_3640575771_sub_3049318236_2560086426(char *t1, char *t2, char *t3)
{
    char t4[336];
    char t5[24];
    char t6[16];
    char t13[8];
    char t18[16];
    char t23[8];
    char t139[16];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    int t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    char *t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t68;
    int t70;
    char *t71;
    int t73;
    char *t74;
    int t76;
    char *t77;
    int t79;
    char *t80;
    int t82;
    char *t83;
    int t85;
    char *t86;
    int t88;
    char *t89;
    int t91;
    char *t92;
    int t94;
    char *t95;
    int t97;
    char *t98;
    int t100;
    char *t101;
    int t103;
    char *t104;
    int t106;
    char *t107;
    int t109;
    char *t110;
    int t112;
    char *t113;
    int t115;
    char *t116;
    int t118;
    char *t119;
    int t121;
    char *t122;
    int t124;
    char *t125;
    int t127;
    char *t128;
    int t130;
    char *t131;
    int t133;
    char *t134;
    int t136;
    char *t137;
    char *t138;
    unsigned int t140;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 7;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t9 = (0 - 7);
    t10 = (t9 * -1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t4 + 4U);
    t11 = ((STD_STANDARD) + 384);
    t12 = (t8 + 88U);
    *((char **)t12) = t11;
    t14 = (t8 + 56U);
    *((char **)t14) = t13;
    *((int *)t13) = 4;
    t15 = (t8 + 80U);
    *((unsigned int *)t15) = 4U;
    t16 = (t4 + 124U);
    t17 = ((STD_STANDARD) + 384);
    t19 = (t18 + 0U);
    *((int *)t19) = 0;
    t19 = (t18 + 4U);
    *((int *)t19) = 8;
    t19 = (t18 + 8U);
    *((int *)t19) = 1;
    t20 = (8 - 0);
    t10 = (t20 * 1);
    t10 = (t10 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t10;
    t19 = (t4 + 244U);
    xsi_create_subtype(t19, ng1, t17, t18, 16);
    t21 = (t4 + 244U);
    t22 = (t16 + 88U);
    *((char **)t22) = t21;
    t24 = (t16 + 56U);
    *((char **)t24) = t23;
    *((int *)t23) = 0;
    t25 = (t16 + 80U);
    *((unsigned int *)t25) = 4U;
    t26 = (t5 + 4U);
    t27 = (t3 != 0);
    if (t27 == 1)
        goto LAB3;

LAB2:    t28 = (t5 + 12U);
    *((char **)t28) = t6;
    t29 = (t1 + 8760);
    t31 = xsi_mem_cmp(t29, t3, 8U);
    if (t31 == 1)
        goto LAB5;

LAB14:    t32 = (t1 + 8768);
    t34 = xsi_mem_cmp(t32, t3, 8U);
    if (t34 == 1)
        goto LAB5;

LAB15:    t35 = (t1 + 8776);
    t37 = xsi_mem_cmp(t35, t3, 8U);
    if (t37 == 1)
        goto LAB5;

LAB16:    t38 = (t1 + 8784);
    t40 = xsi_mem_cmp(t38, t3, 8U);
    if (t40 == 1)
        goto LAB5;

LAB17:    t41 = (t1 + 8792);
    t43 = xsi_mem_cmp(t41, t3, 8U);
    if (t43 == 1)
        goto LAB5;

LAB18:    t44 = (t1 + 8800);
    t46 = xsi_mem_cmp(t44, t3, 8U);
    if (t46 == 1)
        goto LAB5;

LAB19:    t47 = (t1 + 8808);
    t49 = xsi_mem_cmp(t47, t3, 8U);
    if (t49 == 1)
        goto LAB5;

LAB20:    t50 = (t1 + 8816);
    t52 = xsi_mem_cmp(t50, t3, 8U);
    if (t52 == 1)
        goto LAB5;

LAB21:    t53 = (t1 + 8824);
    t55 = xsi_mem_cmp(t53, t3, 8U);
    if (t55 == 1)
        goto LAB6;

LAB22:    t56 = (t1 + 8832);
    t58 = xsi_mem_cmp(t56, t3, 8U);
    if (t58 == 1)
        goto LAB6;

LAB23:    t59 = (t1 + 8840);
    t61 = xsi_mem_cmp(t59, t3, 8U);
    if (t61 == 1)
        goto LAB6;

LAB24:    t62 = (t1 + 8848);
    t64 = xsi_mem_cmp(t62, t3, 8U);
    if (t64 == 1)
        goto LAB6;

LAB25:    t65 = (t1 + 8856);
    t67 = xsi_mem_cmp(t65, t3, 8U);
    if (t67 == 1)
        goto LAB6;

LAB26:    t68 = (t1 + 8864);
    t70 = xsi_mem_cmp(t68, t3, 8U);
    if (t70 == 1)
        goto LAB6;

LAB27:    t71 = (t1 + 8872);
    t73 = xsi_mem_cmp(t71, t3, 8U);
    if (t73 == 1)
        goto LAB6;

LAB28:    t74 = (t1 + 8880);
    t76 = xsi_mem_cmp(t74, t3, 8U);
    if (t76 == 1)
        goto LAB7;

LAB29:    t77 = (t1 + 8888);
    t79 = xsi_mem_cmp(t77, t3, 8U);
    if (t79 == 1)
        goto LAB7;

LAB30:    t80 = (t1 + 8896);
    t82 = xsi_mem_cmp(t80, t3, 8U);
    if (t82 == 1)
        goto LAB7;

LAB31:    t83 = (t1 + 8904);
    t85 = xsi_mem_cmp(t83, t3, 8U);
    if (t85 == 1)
        goto LAB7;

LAB32:    t86 = (t1 + 8912);
    t88 = xsi_mem_cmp(t86, t3, 8U);
    if (t88 == 1)
        goto LAB7;

LAB33:    t89 = (t1 + 8920);
    t91 = xsi_mem_cmp(t89, t3, 8U);
    if (t91 == 1)
        goto LAB7;

LAB34:    t92 = (t1 + 8928);
    t94 = xsi_mem_cmp(t92, t3, 8U);
    if (t94 == 1)
        goto LAB8;

LAB35:    t95 = (t1 + 8936);
    t97 = xsi_mem_cmp(t95, t3, 8U);
    if (t97 == 1)
        goto LAB8;

LAB36:    t98 = (t1 + 8944);
    t100 = xsi_mem_cmp(t98, t3, 8U);
    if (t100 == 1)
        goto LAB8;

LAB37:    t101 = (t1 + 8952);
    t103 = xsi_mem_cmp(t101, t3, 8U);
    if (t103 == 1)
        goto LAB8;

LAB38:    t104 = (t1 + 8960);
    t106 = xsi_mem_cmp(t104, t3, 8U);
    if (t106 == 1)
        goto LAB8;

LAB39:    t107 = (t1 + 8968);
    t109 = xsi_mem_cmp(t107, t3, 8U);
    if (t109 == 1)
        goto LAB9;

LAB40:    t110 = (t1 + 8976);
    t112 = xsi_mem_cmp(t110, t3, 8U);
    if (t112 == 1)
        goto LAB9;

LAB41:    t113 = (t1 + 8984);
    t115 = xsi_mem_cmp(t113, t3, 8U);
    if (t115 == 1)
        goto LAB9;

LAB42:    t116 = (t1 + 8992);
    t118 = xsi_mem_cmp(t116, t3, 8U);
    if (t118 == 1)
        goto LAB9;

LAB43:    t119 = (t1 + 9000);
    t121 = xsi_mem_cmp(t119, t3, 8U);
    if (t121 == 1)
        goto LAB10;

LAB44:    t122 = (t1 + 9008);
    t124 = xsi_mem_cmp(t122, t3, 8U);
    if (t124 == 1)
        goto LAB10;

LAB45:    t125 = (t1 + 9016);
    t127 = xsi_mem_cmp(t125, t3, 8U);
    if (t127 == 1)
        goto LAB10;

LAB46:    t128 = (t1 + 9024);
    t130 = xsi_mem_cmp(t128, t3, 8U);
    if (t130 == 1)
        goto LAB11;

LAB47:    t131 = (t1 + 9032);
    t133 = xsi_mem_cmp(t131, t3, 8U);
    if (t133 == 1)
        goto LAB11;

LAB48:    t134 = (t1 + 9040);
    t136 = xsi_mem_cmp(t134, t3, 8U);
    if (t136 == 1)
        goto LAB12;

LAB49:
LAB13:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 0;

LAB4:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t9 = *((int *)t11);
    t7 = (t8 + 56U);
    t12 = *((char **)t7);
    t20 = *((int *)t12);
    t7 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t139, t9, t20);
    t14 = (t139 + 12U);
    t10 = *((unsigned int *)t14);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t7, t10);
    t15 = (t139 + 0U);
    t31 = *((int *)t15);
    t17 = (t139 + 4U);
    t34 = *((int *)t17);
    t19 = (t139 + 8U);
    t37 = *((int *)t19);
    t21 = (t2 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = t31;
    t22 = (t21 + 4U);
    *((int *)t22) = t34;
    t22 = (t21 + 8U);
    *((int *)t22) = t37;
    t40 = (t34 - t31);
    t140 = (t40 * t37);
    t140 = (t140 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t140;

LAB1:    return t0;
LAB3:    *((char **)t26) = t3;
    goto LAB2;

LAB5:    t137 = (t16 + 56U);
    t138 = *((char **)t137);
    t137 = (t138 + 0);
    *((int *)t137) = 1;
    goto LAB4;

LAB6:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB7:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB8:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 4;
    goto LAB4;

LAB9:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 5;
    goto LAB4;

LAB10:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 6;
    goto LAB4;

LAB11:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 7;
    goto LAB4;

LAB12:    t7 = (t16 + 56U);
    t11 = *((char **)t7);
    t7 = (t11 + 0);
    *((int *)t7) = 8;
    goto LAB4;

LAB50:;
LAB51:;
}

static void axi_datamover_v4_02_a_a_2433371128_3640575771_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(237, ng3);

LAB3:    t1 = (t0 + 1776U);
    t2 = *((char **)t1);
    t1 = (t0 + 4888);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4760);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_2433371128_3640575771_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(239, ng3);

LAB3:    t1 = (t0 + 1296U);
    t2 = *((char **)t1);
    t1 = (t0 + 4952);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);

LAB2:    t7 = (t0 + 4776);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_2433371128_3640575771_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(403, ng3);

LAB3:    t1 = (t0 + 1616U);
    t2 = *((char **)t1);
    t1 = (t0 + 5016);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);

LAB2:    t7 = (t0 + 4792);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_2433371128_3640575771_p_3(char *t0)
{
    char t1[16];
    char t2[16];
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(407, ng3);

LAB3:    t3 = (t0 + 1936U);
    t4 = *((char **)t3);
    t3 = axi_datamover_v4_02_a_a_2433371128_3640575771_sub_3049318236_2560086426(t0, t2, t4);
    t5 = (t0 + 2592U);
    t6 = *((char **)t5);
    t7 = *((int *)t6);
    t5 = ieee_p_1242562249_sub_2045698577_1035706684(IEEE_P_1242562249, t1, t3, t2, t7);
    t8 = (t0 + 5080);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t5, 8U);
    xsi_driver_first_trans_fast(t8);

LAB2:    t13 = (t0 + 4808);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void axi_datamover_v4_02_a_a_2433371128_3640575771_init()
{
	static char *pe[] = {(void *)axi_datamover_v4_02_a_a_2433371128_3640575771_p_0,(void *)axi_datamover_v4_02_a_a_2433371128_3640575771_p_1,(void *)axi_datamover_v4_02_a_a_2433371128_3640575771_p_2,(void *)axi_datamover_v4_02_a_a_2433371128_3640575771_p_3};
	static char *se[] = {(void *)axi_datamover_v4_02_a_a_2433371128_3640575771_sub_3049318236_2560086426};
	xsi_register_didat("axi_datamover_v4_02_a_a_2433371128_3640575771", "isim/module_1_stub.exe.sim/axi_datamover_v4_02_a/a_2433371128_3640575771.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
