/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;
static const char *ng2 = "C:/xilinx/14.7/ISE_DS/EDK/hw/XilinxProcessorIPLib/pcores/axi_datamover_v4_02_a/hdl/vhdl/axi_datamover_ms_strb_set.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );


int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877951117_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[8];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 1;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 1);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 2U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 1);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 1, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 1);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 11928);
    t15 = xsi_mem_cmp(t7, t8, 2U);
    if (t15 == 1)
        goto LAB5;

LAB8:    t11 = (t1 + 11930);
    t27 = xsi_mem_cmp(t11, t8, 2U);
    if (t27 == 1)
        goto LAB6;

LAB9:    t17 = (t1 + 11932);
    t29 = xsi_mem_cmp(t17, t8, 2U);
    if (t29 == 1)
        goto LAB6;

LAB10:
LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t20 = (t6 + 56U);
    t21 = *((char **)t20);
    t20 = (t21 + 0);
    *((int *)t20) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB11:;
LAB12:;
}

int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877953295_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[8];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    int t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    char *t51;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 3;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 3);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 4U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 3);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 3, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 3);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 11934);
    t15 = xsi_mem_cmp(t7, t8, 4U);
    if (t15 == 1)
        goto LAB5;

LAB10:    t11 = (t1 + 11938);
    t27 = xsi_mem_cmp(t11, t8, 4U);
    if (t27 == 1)
        goto LAB6;

LAB11:    t17 = (t1 + 11942);
    t29 = xsi_mem_cmp(t17, t8, 4U);
    if (t29 == 1)
        goto LAB6;

LAB12:    t20 = (t1 + 11946);
    t31 = xsi_mem_cmp(t20, t8, 4U);
    if (t31 == 1)
        goto LAB7;

LAB13:    t22 = (t1 + 11950);
    t37 = xsi_mem_cmp(t22, t8, 4U);
    if (t37 == 1)
        goto LAB7;

LAB14:    t28 = (t1 + 11954);
    t40 = xsi_mem_cmp(t28, t8, 4U);
    if (t40 == 1)
        goto LAB7;

LAB15:    t34 = (t1 + 11958);
    t41 = xsi_mem_cmp(t34, t8, 4U);
    if (t41 == 1)
        goto LAB8;

LAB16:    t36 = (t1 + 11962);
    t43 = xsi_mem_cmp(t36, t8, 4U);
    if (t43 == 1)
        goto LAB8;

LAB17:    t44 = (t1 + 11966);
    t46 = xsi_mem_cmp(t44, t8, 4U);
    if (t46 == 1)
        goto LAB8;

LAB18:    t47 = (t1 + 11970);
    t49 = xsi_mem_cmp(t47, t8, 4U);
    if (t49 == 1)
        goto LAB8;

LAB19:
LAB9:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 4;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t50 = (t6 + 56U);
    t51 = *((char **)t50);
    t50 = (t51 + 0);
    *((int *)t50) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB8:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB20:;
LAB21:;
}

int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877957651_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[8];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    int t41;
    int t43;
    char *t44;
    char *t45;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 7;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 7);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 8U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 7);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 7, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 7);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 11974);
    t15 = xsi_mem_cmp(t7, t8, 8U);
    if (t15 == 1)
        goto LAB5;

LAB14:    t11 = (t1 + 11982);
    t27 = xsi_mem_cmp(t11, t8, 8U);
    if (t27 == 1)
        goto LAB6;

LAB15:    t17 = (t1 + 11990);
    t29 = xsi_mem_cmp(t17, t8, 8U);
    if (t29 == 1)
        goto LAB7;

LAB16:    t20 = (t1 + 11998);
    t31 = xsi_mem_cmp(t20, t8, 8U);
    if (t31 == 1)
        goto LAB8;

LAB17:    t22 = (t1 + 12006);
    t37 = xsi_mem_cmp(t22, t8, 8U);
    if (t37 == 1)
        goto LAB9;

LAB18:    t28 = (t1 + 12014);
    t40 = xsi_mem_cmp(t28, t8, 8U);
    if (t40 == 1)
        goto LAB10;

LAB19:    t34 = (t1 + 12022);
    t41 = xsi_mem_cmp(t34, t8, 8U);
    if (t41 == 1)
        goto LAB11;

LAB20:    t36 = (t1 + 12030);
    t43 = xsi_mem_cmp(t36, t8, 8U);
    if (t43 == 1)
        goto LAB12;

LAB21:
LAB13:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 8;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t44 = (t6 + 56U);
    t45 = *((char **)t44);
    t44 = (t45 + 0);
    *((int *)t44) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB8:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB9:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 4;
    goto LAB4;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 5;
    goto LAB4;

LAB11:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 6;
    goto LAB4;

LAB12:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 7;
    goto LAB4;

LAB22:;
LAB23:;
}

int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_1565228898_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[16];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    int t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t68;
    char *t69;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 15;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 15);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 16U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 15);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 15, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 15);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 12038);
    t15 = xsi_mem_cmp(t7, t8, 16U);
    if (t15 == 1)
        goto LAB5;

LAB22:    t11 = (t1 + 12054);
    t27 = xsi_mem_cmp(t11, t8, 16U);
    if (t27 == 1)
        goto LAB6;

LAB23:    t17 = (t1 + 12070);
    t29 = xsi_mem_cmp(t17, t8, 16U);
    if (t29 == 1)
        goto LAB7;

LAB24:    t20 = (t1 + 12086);
    t31 = xsi_mem_cmp(t20, t8, 16U);
    if (t31 == 1)
        goto LAB8;

LAB25:    t22 = (t1 + 12102);
    t37 = xsi_mem_cmp(t22, t8, 16U);
    if (t37 == 1)
        goto LAB9;

LAB26:    t28 = (t1 + 12118);
    t40 = xsi_mem_cmp(t28, t8, 16U);
    if (t40 == 1)
        goto LAB10;

LAB27:    t34 = (t1 + 12134);
    t41 = xsi_mem_cmp(t34, t8, 16U);
    if (t41 == 1)
        goto LAB11;

LAB28:    t36 = (t1 + 12150);
    t43 = xsi_mem_cmp(t36, t8, 16U);
    if (t43 == 1)
        goto LAB12;

LAB29:    t44 = (t1 + 12166);
    t46 = xsi_mem_cmp(t44, t8, 16U);
    if (t46 == 1)
        goto LAB13;

LAB30:    t47 = (t1 + 12182);
    t49 = xsi_mem_cmp(t47, t8, 16U);
    if (t49 == 1)
        goto LAB14;

LAB31:    t50 = (t1 + 12198);
    t52 = xsi_mem_cmp(t50, t8, 16U);
    if (t52 == 1)
        goto LAB15;

LAB32:    t53 = (t1 + 12214);
    t55 = xsi_mem_cmp(t53, t8, 16U);
    if (t55 == 1)
        goto LAB16;

LAB33:    t56 = (t1 + 12230);
    t58 = xsi_mem_cmp(t56, t8, 16U);
    if (t58 == 1)
        goto LAB17;

LAB34:    t59 = (t1 + 12246);
    t61 = xsi_mem_cmp(t59, t8, 16U);
    if (t61 == 1)
        goto LAB18;

LAB35:    t62 = (t1 + 12262);
    t64 = xsi_mem_cmp(t62, t8, 16U);
    if (t64 == 1)
        goto LAB19;

LAB36:    t65 = (t1 + 12278);
    t67 = xsi_mem_cmp(t65, t8, 16U);
    if (t67 == 1)
        goto LAB20;

LAB37:
LAB21:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 16;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t68 = (t6 + 56U);
    t69 = *((char **)t68);
    t68 = (t69 + 0);
    *((int *)t68) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB8:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB9:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 4;
    goto LAB4;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 5;
    goto LAB4;

LAB11:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 6;
    goto LAB4;

LAB12:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 7;
    goto LAB4;

LAB13:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 8;
    goto LAB4;

LAB14:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 9;
    goto LAB4;

LAB15:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 10;
    goto LAB4;

LAB16:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 11;
    goto LAB4;

LAB17:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 12;
    goto LAB4;

LAB18:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 13;
    goto LAB4;

LAB19:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 14;
    goto LAB4;

LAB20:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 15;
    goto LAB4;

LAB38:;
LAB39:;
}

int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_1565296416_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[32];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    int t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t68;
    int t70;
    char *t71;
    int t73;
    char *t74;
    int t76;
    char *t77;
    int t79;
    char *t80;
    int t82;
    char *t83;
    int t85;
    char *t86;
    int t88;
    char *t89;
    int t91;
    char *t92;
    int t94;
    char *t95;
    int t97;
    char *t98;
    int t100;
    char *t101;
    int t103;
    char *t104;
    int t106;
    char *t107;
    int t109;
    char *t110;
    int t112;
    char *t113;
    int t115;
    char *t116;
    char *t117;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 31;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 31);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 32U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 31);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 31, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 31);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 12294);
    t15 = xsi_mem_cmp(t7, t8, 32U);
    if (t15 == 1)
        goto LAB5;

LAB38:    t11 = (t1 + 12326);
    t27 = xsi_mem_cmp(t11, t8, 32U);
    if (t27 == 1)
        goto LAB6;

LAB39:    t17 = (t1 + 12358);
    t29 = xsi_mem_cmp(t17, t8, 32U);
    if (t29 == 1)
        goto LAB7;

LAB40:    t20 = (t1 + 12390);
    t31 = xsi_mem_cmp(t20, t8, 32U);
    if (t31 == 1)
        goto LAB8;

LAB41:    t22 = (t1 + 12422);
    t37 = xsi_mem_cmp(t22, t8, 32U);
    if (t37 == 1)
        goto LAB9;

LAB42:    t28 = (t1 + 12454);
    t40 = xsi_mem_cmp(t28, t8, 32U);
    if (t40 == 1)
        goto LAB10;

LAB43:    t34 = (t1 + 12486);
    t41 = xsi_mem_cmp(t34, t8, 32U);
    if (t41 == 1)
        goto LAB11;

LAB44:    t36 = (t1 + 12518);
    t43 = xsi_mem_cmp(t36, t8, 32U);
    if (t43 == 1)
        goto LAB12;

LAB45:    t44 = (t1 + 12550);
    t46 = xsi_mem_cmp(t44, t8, 32U);
    if (t46 == 1)
        goto LAB13;

LAB46:    t47 = (t1 + 12582);
    t49 = xsi_mem_cmp(t47, t8, 32U);
    if (t49 == 1)
        goto LAB14;

LAB47:    t50 = (t1 + 12614);
    t52 = xsi_mem_cmp(t50, t8, 32U);
    if (t52 == 1)
        goto LAB15;

LAB48:    t53 = (t1 + 12646);
    t55 = xsi_mem_cmp(t53, t8, 32U);
    if (t55 == 1)
        goto LAB16;

LAB49:    t56 = (t1 + 12678);
    t58 = xsi_mem_cmp(t56, t8, 32U);
    if (t58 == 1)
        goto LAB17;

LAB50:    t59 = (t1 + 12710);
    t61 = xsi_mem_cmp(t59, t8, 32U);
    if (t61 == 1)
        goto LAB18;

LAB51:    t62 = (t1 + 12742);
    t64 = xsi_mem_cmp(t62, t8, 32U);
    if (t64 == 1)
        goto LAB19;

LAB52:    t65 = (t1 + 12774);
    t67 = xsi_mem_cmp(t65, t8, 32U);
    if (t67 == 1)
        goto LAB20;

LAB53:    t68 = (t1 + 12806);
    t70 = xsi_mem_cmp(t68, t8, 32U);
    if (t70 == 1)
        goto LAB21;

LAB54:    t71 = (t1 + 12838);
    t73 = xsi_mem_cmp(t71, t8, 32U);
    if (t73 == 1)
        goto LAB22;

LAB55:    t74 = (t1 + 12870);
    t76 = xsi_mem_cmp(t74, t8, 32U);
    if (t76 == 1)
        goto LAB23;

LAB56:    t77 = (t1 + 12902);
    t79 = xsi_mem_cmp(t77, t8, 32U);
    if (t79 == 1)
        goto LAB24;

LAB57:    t80 = (t1 + 12934);
    t82 = xsi_mem_cmp(t80, t8, 32U);
    if (t82 == 1)
        goto LAB25;

LAB58:    t83 = (t1 + 12966);
    t85 = xsi_mem_cmp(t83, t8, 32U);
    if (t85 == 1)
        goto LAB26;

LAB59:    t86 = (t1 + 12998);
    t88 = xsi_mem_cmp(t86, t8, 32U);
    if (t88 == 1)
        goto LAB27;

LAB60:    t89 = (t1 + 13030);
    t91 = xsi_mem_cmp(t89, t8, 32U);
    if (t91 == 1)
        goto LAB28;

LAB61:    t92 = (t1 + 13062);
    t94 = xsi_mem_cmp(t92, t8, 32U);
    if (t94 == 1)
        goto LAB29;

LAB62:    t95 = (t1 + 13094);
    t97 = xsi_mem_cmp(t95, t8, 32U);
    if (t97 == 1)
        goto LAB30;

LAB63:    t98 = (t1 + 13126);
    t100 = xsi_mem_cmp(t98, t8, 32U);
    if (t100 == 1)
        goto LAB31;

LAB64:    t101 = (t1 + 13158);
    t103 = xsi_mem_cmp(t101, t8, 32U);
    if (t103 == 1)
        goto LAB32;

LAB65:    t104 = (t1 + 13190);
    t106 = xsi_mem_cmp(t104, t8, 32U);
    if (t106 == 1)
        goto LAB33;

LAB66:    t107 = (t1 + 13222);
    t109 = xsi_mem_cmp(t107, t8, 32U);
    if (t109 == 1)
        goto LAB34;

LAB67:    t110 = (t1 + 13254);
    t112 = xsi_mem_cmp(t110, t8, 32U);
    if (t112 == 1)
        goto LAB35;

LAB68:    t113 = (t1 + 13286);
    t115 = xsi_mem_cmp(t113, t8, 32U);
    if (t115 == 1)
        goto LAB36;

LAB69:
LAB37:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 32;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t116 = (t6 + 56U);
    t117 = *((char **)t116);
    t116 = (t117 + 0);
    *((int *)t116) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB8:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB9:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 4;
    goto LAB4;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 5;
    goto LAB4;

LAB11:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 6;
    goto LAB4;

LAB12:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 7;
    goto LAB4;

LAB13:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 8;
    goto LAB4;

LAB14:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 9;
    goto LAB4;

LAB15:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 10;
    goto LAB4;

LAB16:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 11;
    goto LAB4;

LAB17:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 12;
    goto LAB4;

LAB18:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 13;
    goto LAB4;

LAB19:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 14;
    goto LAB4;

LAB20:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 15;
    goto LAB4;

LAB21:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 16;
    goto LAB4;

LAB22:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 17;
    goto LAB4;

LAB23:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 18;
    goto LAB4;

LAB24:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 19;
    goto LAB4;

LAB25:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 20;
    goto LAB4;

LAB26:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 21;
    goto LAB4;

LAB27:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 22;
    goto LAB4;

LAB28:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 23;
    goto LAB4;

LAB29:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 24;
    goto LAB4;

LAB30:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 25;
    goto LAB4;

LAB31:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 26;
    goto LAB4;

LAB32:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 27;
    goto LAB4;

LAB33:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 28;
    goto LAB4;

LAB34:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 29;
    goto LAB4;

LAB35:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 30;
    goto LAB4;

LAB36:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 31;
    goto LAB4;

LAB70:;
LAB71:;
}

int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_1565406405_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[64];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    int t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t68;
    int t70;
    char *t71;
    int t73;
    char *t74;
    int t76;
    char *t77;
    int t79;
    char *t80;
    int t82;
    char *t83;
    int t85;
    char *t86;
    int t88;
    char *t89;
    int t91;
    char *t92;
    int t94;
    char *t95;
    int t97;
    char *t98;
    int t100;
    char *t101;
    int t103;
    char *t104;
    int t106;
    char *t107;
    int t109;
    char *t110;
    int t112;
    char *t113;
    int t115;
    char *t116;
    int t118;
    char *t119;
    int t121;
    char *t122;
    int t124;
    char *t125;
    int t127;
    char *t128;
    int t130;
    char *t131;
    int t133;
    char *t134;
    int t136;
    char *t137;
    int t139;
    char *t140;
    int t142;
    char *t143;
    int t145;
    char *t146;
    int t148;
    char *t149;
    int t151;
    char *t152;
    int t154;
    char *t155;
    int t157;
    char *t158;
    int t160;
    char *t161;
    int t163;
    char *t164;
    int t166;
    char *t167;
    int t169;
    char *t170;
    int t172;
    char *t173;
    int t175;
    char *t176;
    int t178;
    char *t179;
    int t181;
    char *t182;
    int t184;
    char *t185;
    int t187;
    char *t188;
    int t190;
    char *t191;
    int t193;
    char *t194;
    int t196;
    char *t197;
    int t199;
    char *t200;
    int t202;
    char *t203;
    int t205;
    char *t206;
    int t208;
    char *t209;
    int t211;
    char *t212;
    char *t213;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 63;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 63);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 64U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 63);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 63, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 63);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 13318);
    t15 = xsi_mem_cmp(t7, t8, 64U);
    if (t15 == 1)
        goto LAB5;

LAB70:    t11 = (t1 + 13382);
    t27 = xsi_mem_cmp(t11, t8, 64U);
    if (t27 == 1)
        goto LAB6;

LAB71:    t17 = (t1 + 13446);
    t29 = xsi_mem_cmp(t17, t8, 64U);
    if (t29 == 1)
        goto LAB7;

LAB72:    t20 = (t1 + 13510);
    t31 = xsi_mem_cmp(t20, t8, 64U);
    if (t31 == 1)
        goto LAB8;

LAB73:    t22 = (t1 + 13574);
    t37 = xsi_mem_cmp(t22, t8, 64U);
    if (t37 == 1)
        goto LAB9;

LAB74:    t28 = (t1 + 13638);
    t40 = xsi_mem_cmp(t28, t8, 64U);
    if (t40 == 1)
        goto LAB10;

LAB75:    t34 = (t1 + 13702);
    t41 = xsi_mem_cmp(t34, t8, 64U);
    if (t41 == 1)
        goto LAB11;

LAB76:    t36 = (t1 + 13766);
    t43 = xsi_mem_cmp(t36, t8, 64U);
    if (t43 == 1)
        goto LAB12;

LAB77:    t44 = (t1 + 13830);
    t46 = xsi_mem_cmp(t44, t8, 64U);
    if (t46 == 1)
        goto LAB13;

LAB78:    t47 = (t1 + 13894);
    t49 = xsi_mem_cmp(t47, t8, 64U);
    if (t49 == 1)
        goto LAB14;

LAB79:    t50 = (t1 + 13958);
    t52 = xsi_mem_cmp(t50, t8, 64U);
    if (t52 == 1)
        goto LAB15;

LAB80:    t53 = (t1 + 14022);
    t55 = xsi_mem_cmp(t53, t8, 64U);
    if (t55 == 1)
        goto LAB16;

LAB81:    t56 = (t1 + 14086);
    t58 = xsi_mem_cmp(t56, t8, 64U);
    if (t58 == 1)
        goto LAB17;

LAB82:    t59 = (t1 + 14150);
    t61 = xsi_mem_cmp(t59, t8, 64U);
    if (t61 == 1)
        goto LAB18;

LAB83:    t62 = (t1 + 14214);
    t64 = xsi_mem_cmp(t62, t8, 64U);
    if (t64 == 1)
        goto LAB19;

LAB84:    t65 = (t1 + 14278);
    t67 = xsi_mem_cmp(t65, t8, 64U);
    if (t67 == 1)
        goto LAB20;

LAB85:    t68 = (t1 + 14342);
    t70 = xsi_mem_cmp(t68, t8, 64U);
    if (t70 == 1)
        goto LAB21;

LAB86:    t71 = (t1 + 14406);
    t73 = xsi_mem_cmp(t71, t8, 64U);
    if (t73 == 1)
        goto LAB22;

LAB87:    t74 = (t1 + 14470);
    t76 = xsi_mem_cmp(t74, t8, 64U);
    if (t76 == 1)
        goto LAB23;

LAB88:    t77 = (t1 + 14534);
    t79 = xsi_mem_cmp(t77, t8, 64U);
    if (t79 == 1)
        goto LAB24;

LAB89:    t80 = (t1 + 14598);
    t82 = xsi_mem_cmp(t80, t8, 64U);
    if (t82 == 1)
        goto LAB25;

LAB90:    t83 = (t1 + 14662);
    t85 = xsi_mem_cmp(t83, t8, 64U);
    if (t85 == 1)
        goto LAB26;

LAB91:    t86 = (t1 + 14726);
    t88 = xsi_mem_cmp(t86, t8, 64U);
    if (t88 == 1)
        goto LAB27;

LAB92:    t89 = (t1 + 14790);
    t91 = xsi_mem_cmp(t89, t8, 64U);
    if (t91 == 1)
        goto LAB28;

LAB93:    t92 = (t1 + 14854);
    t94 = xsi_mem_cmp(t92, t8, 64U);
    if (t94 == 1)
        goto LAB29;

LAB94:    t95 = (t1 + 14918);
    t97 = xsi_mem_cmp(t95, t8, 64U);
    if (t97 == 1)
        goto LAB30;

LAB95:    t98 = (t1 + 14982);
    t100 = xsi_mem_cmp(t98, t8, 64U);
    if (t100 == 1)
        goto LAB31;

LAB96:    t101 = (t1 + 15046);
    t103 = xsi_mem_cmp(t101, t8, 64U);
    if (t103 == 1)
        goto LAB32;

LAB97:    t104 = (t1 + 15110);
    t106 = xsi_mem_cmp(t104, t8, 64U);
    if (t106 == 1)
        goto LAB33;

LAB98:    t107 = (t1 + 15174);
    t109 = xsi_mem_cmp(t107, t8, 64U);
    if (t109 == 1)
        goto LAB34;

LAB99:    t110 = (t1 + 15238);
    t112 = xsi_mem_cmp(t110, t8, 64U);
    if (t112 == 1)
        goto LAB35;

LAB100:    t113 = (t1 + 15302);
    t115 = xsi_mem_cmp(t113, t8, 64U);
    if (t115 == 1)
        goto LAB36;

LAB101:    t116 = (t1 + 15366);
    t118 = xsi_mem_cmp(t116, t8, 64U);
    if (t118 == 1)
        goto LAB37;

LAB102:    t119 = (t1 + 15430);
    t121 = xsi_mem_cmp(t119, t8, 64U);
    if (t121 == 1)
        goto LAB38;

LAB103:    t122 = (t1 + 15494);
    t124 = xsi_mem_cmp(t122, t8, 64U);
    if (t124 == 1)
        goto LAB39;

LAB104:    t125 = (t1 + 15558);
    t127 = xsi_mem_cmp(t125, t8, 64U);
    if (t127 == 1)
        goto LAB40;

LAB105:    t128 = (t1 + 15622);
    t130 = xsi_mem_cmp(t128, t8, 64U);
    if (t130 == 1)
        goto LAB41;

LAB106:    t131 = (t1 + 15686);
    t133 = xsi_mem_cmp(t131, t8, 64U);
    if (t133 == 1)
        goto LAB42;

LAB107:    t134 = (t1 + 15750);
    t136 = xsi_mem_cmp(t134, t8, 64U);
    if (t136 == 1)
        goto LAB43;

LAB108:    t137 = (t1 + 15814);
    t139 = xsi_mem_cmp(t137, t8, 64U);
    if (t139 == 1)
        goto LAB44;

LAB109:    t140 = (t1 + 15878);
    t142 = xsi_mem_cmp(t140, t8, 64U);
    if (t142 == 1)
        goto LAB45;

LAB110:    t143 = (t1 + 15942);
    t145 = xsi_mem_cmp(t143, t8, 64U);
    if (t145 == 1)
        goto LAB46;

LAB111:    t146 = (t1 + 16006);
    t148 = xsi_mem_cmp(t146, t8, 64U);
    if (t148 == 1)
        goto LAB47;

LAB112:    t149 = (t1 + 16070);
    t151 = xsi_mem_cmp(t149, t8, 64U);
    if (t151 == 1)
        goto LAB48;

LAB113:    t152 = (t1 + 16134);
    t154 = xsi_mem_cmp(t152, t8, 64U);
    if (t154 == 1)
        goto LAB49;

LAB114:    t155 = (t1 + 16198);
    t157 = xsi_mem_cmp(t155, t8, 64U);
    if (t157 == 1)
        goto LAB50;

LAB115:    t158 = (t1 + 16262);
    t160 = xsi_mem_cmp(t158, t8, 64U);
    if (t160 == 1)
        goto LAB51;

LAB116:    t161 = (t1 + 16326);
    t163 = xsi_mem_cmp(t161, t8, 64U);
    if (t163 == 1)
        goto LAB52;

LAB117:    t164 = (t1 + 16390);
    t166 = xsi_mem_cmp(t164, t8, 64U);
    if (t166 == 1)
        goto LAB53;

LAB118:    t167 = (t1 + 16454);
    t169 = xsi_mem_cmp(t167, t8, 64U);
    if (t169 == 1)
        goto LAB54;

LAB119:    t170 = (t1 + 16518);
    t172 = xsi_mem_cmp(t170, t8, 64U);
    if (t172 == 1)
        goto LAB55;

LAB120:    t173 = (t1 + 16582);
    t175 = xsi_mem_cmp(t173, t8, 64U);
    if (t175 == 1)
        goto LAB56;

LAB121:    t176 = (t1 + 16646);
    t178 = xsi_mem_cmp(t176, t8, 64U);
    if (t178 == 1)
        goto LAB57;

LAB122:    t179 = (t1 + 16710);
    t181 = xsi_mem_cmp(t179, t8, 64U);
    if (t181 == 1)
        goto LAB58;

LAB123:    t182 = (t1 + 16774);
    t184 = xsi_mem_cmp(t182, t8, 64U);
    if (t184 == 1)
        goto LAB59;

LAB124:    t185 = (t1 + 16838);
    t187 = xsi_mem_cmp(t185, t8, 64U);
    if (t187 == 1)
        goto LAB60;

LAB125:    t188 = (t1 + 16902);
    t190 = xsi_mem_cmp(t188, t8, 64U);
    if (t190 == 1)
        goto LAB61;

LAB126:    t191 = (t1 + 16966);
    t193 = xsi_mem_cmp(t191, t8, 64U);
    if (t193 == 1)
        goto LAB62;

LAB127:    t194 = (t1 + 17030);
    t196 = xsi_mem_cmp(t194, t8, 64U);
    if (t196 == 1)
        goto LAB63;

LAB128:    t197 = (t1 + 17094);
    t199 = xsi_mem_cmp(t197, t8, 64U);
    if (t199 == 1)
        goto LAB64;

LAB129:    t200 = (t1 + 17158);
    t202 = xsi_mem_cmp(t200, t8, 64U);
    if (t202 == 1)
        goto LAB65;

LAB130:    t203 = (t1 + 17222);
    t205 = xsi_mem_cmp(t203, t8, 64U);
    if (t205 == 1)
        goto LAB66;

LAB131:    t206 = (t1 + 17286);
    t208 = xsi_mem_cmp(t206, t8, 64U);
    if (t208 == 1)
        goto LAB67;

LAB132:    t209 = (t1 + 17350);
    t211 = xsi_mem_cmp(t209, t8, 64U);
    if (t211 == 1)
        goto LAB68;

LAB133:
LAB69:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 64;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t212 = (t6 + 56U);
    t213 = *((char **)t212);
    t212 = (t213 + 0);
    *((int *)t212) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB8:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB9:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 4;
    goto LAB4;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 5;
    goto LAB4;

LAB11:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 6;
    goto LAB4;

LAB12:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 7;
    goto LAB4;

LAB13:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 8;
    goto LAB4;

LAB14:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 9;
    goto LAB4;

LAB15:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 10;
    goto LAB4;

LAB16:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 11;
    goto LAB4;

LAB17:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 12;
    goto LAB4;

LAB18:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 13;
    goto LAB4;

LAB19:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 14;
    goto LAB4;

LAB20:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 15;
    goto LAB4;

LAB21:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 16;
    goto LAB4;

LAB22:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 17;
    goto LAB4;

LAB23:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 18;
    goto LAB4;

LAB24:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 19;
    goto LAB4;

LAB25:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 20;
    goto LAB4;

LAB26:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 21;
    goto LAB4;

LAB27:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 22;
    goto LAB4;

LAB28:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 23;
    goto LAB4;

LAB29:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 24;
    goto LAB4;

LAB30:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 25;
    goto LAB4;

LAB31:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 26;
    goto LAB4;

LAB32:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 27;
    goto LAB4;

LAB33:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 28;
    goto LAB4;

LAB34:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 29;
    goto LAB4;

LAB35:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 30;
    goto LAB4;

LAB36:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 31;
    goto LAB4;

LAB37:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 32;
    goto LAB4;

LAB38:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 33;
    goto LAB4;

LAB39:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 34;
    goto LAB4;

LAB40:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 35;
    goto LAB4;

LAB41:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 36;
    goto LAB4;

LAB42:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 37;
    goto LAB4;

LAB43:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 38;
    goto LAB4;

LAB44:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 39;
    goto LAB4;

LAB45:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 40;
    goto LAB4;

LAB46:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 41;
    goto LAB4;

LAB47:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 42;
    goto LAB4;

LAB48:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 43;
    goto LAB4;

LAB49:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 44;
    goto LAB4;

LAB50:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 45;
    goto LAB4;

LAB51:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 46;
    goto LAB4;

LAB52:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 47;
    goto LAB4;

LAB53:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 48;
    goto LAB4;

LAB54:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 49;
    goto LAB4;

LAB55:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 50;
    goto LAB4;

LAB56:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 51;
    goto LAB4;

LAB57:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 52;
    goto LAB4;

LAB58:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 53;
    goto LAB4;

LAB59:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 54;
    goto LAB4;

LAB60:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 55;
    goto LAB4;

LAB61:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 56;
    goto LAB4;

LAB62:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 57;
    goto LAB4;

LAB63:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 58;
    goto LAB4;

LAB64:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 59;
    goto LAB4;

LAB65:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 60;
    goto LAB4;

LAB66:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 61;
    goto LAB4;

LAB67:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 62;
    goto LAB4;

LAB68:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 63;
    goto LAB4;

LAB134:;
LAB135:;
}

int axi_datamover_v4_02_a_a_1215259340_3640575771_sub_2770453558_2560086426(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t12[16];
    char t19[128];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    int t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t68;
    int t70;
    char *t71;
    int t73;
    char *t74;
    int t76;
    char *t77;
    int t79;
    char *t80;
    int t82;
    char *t83;
    int t85;
    char *t86;
    int t88;
    char *t89;
    int t91;
    char *t92;
    int t94;
    char *t95;
    int t97;
    char *t98;
    int t100;
    char *t101;
    int t103;
    char *t104;
    int t106;
    char *t107;
    int t109;
    char *t110;
    int t112;
    char *t113;
    int t115;
    char *t116;
    int t118;
    char *t119;
    int t121;
    char *t122;
    int t124;
    char *t125;
    int t127;
    char *t128;
    int t130;
    char *t131;
    int t133;
    char *t134;
    int t136;
    char *t137;
    int t139;
    char *t140;
    int t142;
    char *t143;
    int t145;
    char *t146;
    int t148;
    char *t149;
    int t151;
    char *t152;
    int t154;
    char *t155;
    int t157;
    char *t158;
    int t160;
    char *t161;
    int t163;
    char *t164;
    int t166;
    char *t167;
    int t169;
    char *t170;
    int t172;
    char *t173;
    int t175;
    char *t176;
    int t178;
    char *t179;
    int t181;
    char *t182;
    int t184;
    char *t185;
    int t187;
    char *t188;
    int t190;
    char *t191;
    int t193;
    char *t194;
    int t196;
    char *t197;
    int t199;
    char *t200;
    int t202;
    char *t203;
    int t205;
    char *t206;
    int t208;
    char *t209;
    int t211;
    char *t212;
    int t214;
    char *t215;
    int t217;
    char *t218;
    int t220;
    char *t221;
    int t223;
    char *t224;
    int t226;
    char *t227;
    int t229;
    char *t230;
    int t232;
    char *t233;
    int t235;
    char *t236;
    int t238;
    char *t239;
    int t241;
    char *t242;
    int t244;
    char *t245;
    int t247;
    char *t248;
    int t250;
    char *t251;
    int t253;
    char *t254;
    int t256;
    char *t257;
    int t259;
    char *t260;
    int t262;
    char *t263;
    int t265;
    char *t266;
    int t268;
    char *t269;
    int t271;
    char *t272;
    int t274;
    char *t275;
    int t277;
    char *t278;
    int t280;
    char *t281;
    int t283;
    char *t284;
    int t286;
    char *t287;
    int t289;
    char *t290;
    int t292;
    char *t293;
    int t295;
    char *t296;
    int t298;
    char *t299;
    int t301;
    char *t302;
    int t304;
    char *t305;
    int t307;
    char *t308;
    int t310;
    char *t311;
    int t313;
    char *t314;
    int t316;
    char *t317;
    int t319;
    char *t320;
    int t322;
    char *t323;
    int t325;
    char *t326;
    int t328;
    char *t329;
    int t331;
    char *t332;
    int t334;
    char *t335;
    int t337;
    char *t338;
    int t340;
    char *t341;
    int t343;
    char *t344;
    int t346;
    char *t347;
    int t349;
    char *t350;
    int t352;
    char *t353;
    int t355;
    char *t356;
    int t358;
    char *t359;
    int t361;
    char *t362;
    int t364;
    char *t365;
    int t367;
    char *t368;
    int t370;
    char *t371;
    int t373;
    char *t374;
    int t376;
    char *t377;
    int t379;
    char *t380;
    int t382;
    char *t383;
    int t385;
    char *t386;
    int t388;
    char *t389;
    int t391;
    char *t392;
    int t394;
    char *t395;
    int t397;
    char *t398;
    int t400;
    char *t401;
    int t403;
    char *t404;
    char *t405;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 832);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 127;
    t14 = (t13 + 4U);
    *((int *)t14) = 0;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t15 = (0 - 127);
    t16 = (t15 * -1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t4 + 124U);
    t17 = ((IEEE_P_2592010699) + 4024);
    t18 = (t14 + 88U);
    *((char **)t18) = t17;
    t20 = (t14 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t12);
    t21 = (t14 + 64U);
    *((char **)t21) = t12;
    t22 = (t14 + 80U);
    *((unsigned int *)t22) = 128U;
    t23 = (t5 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t5 + 12U);
    *((char **)t25) = t3;
    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t16 = (t27 - 127);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = (t3 + 8U);
    t31 = *((int *)t30);
    xsi_vhdl_check_range_of_slice(t27, t29, t31, 127, 0, -1);
    t32 = (t16 * 1U);
    t33 = (0 + t32);
    t34 = (t2 + t33);
    t35 = (t14 + 56U);
    t36 = *((char **)t35);
    t35 = (t36 + 0);
    t37 = (0 - 127);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t39 = (1U * t38);
    memcpy(t35, t34, t39);
    t7 = (t14 + 56U);
    t8 = *((char **)t7);
    t7 = (t1 + 17414);
    t15 = xsi_mem_cmp(t7, t8, 128U);
    if (t15 == 1)
        goto LAB5;

LAB134:    t11 = (t1 + 17542);
    t27 = xsi_mem_cmp(t11, t8, 128U);
    if (t27 == 1)
        goto LAB6;

LAB135:    t17 = (t1 + 17670);
    t29 = xsi_mem_cmp(t17, t8, 128U);
    if (t29 == 1)
        goto LAB7;

LAB136:    t20 = (t1 + 17798);
    t31 = xsi_mem_cmp(t20, t8, 128U);
    if (t31 == 1)
        goto LAB8;

LAB137:    t22 = (t1 + 17926);
    t37 = xsi_mem_cmp(t22, t8, 128U);
    if (t37 == 1)
        goto LAB9;

LAB138:    t28 = (t1 + 18054);
    t40 = xsi_mem_cmp(t28, t8, 128U);
    if (t40 == 1)
        goto LAB10;

LAB139:    t34 = (t1 + 18182);
    t41 = xsi_mem_cmp(t34, t8, 128U);
    if (t41 == 1)
        goto LAB11;

LAB140:    t36 = (t1 + 18310);
    t43 = xsi_mem_cmp(t36, t8, 128U);
    if (t43 == 1)
        goto LAB12;

LAB141:    t44 = (t1 + 18438);
    t46 = xsi_mem_cmp(t44, t8, 128U);
    if (t46 == 1)
        goto LAB13;

LAB142:    t47 = (t1 + 18566);
    t49 = xsi_mem_cmp(t47, t8, 128U);
    if (t49 == 1)
        goto LAB14;

LAB143:    t50 = (t1 + 18694);
    t52 = xsi_mem_cmp(t50, t8, 128U);
    if (t52 == 1)
        goto LAB15;

LAB144:    t53 = (t1 + 18822);
    t55 = xsi_mem_cmp(t53, t8, 128U);
    if (t55 == 1)
        goto LAB16;

LAB145:    t56 = (t1 + 18950);
    t58 = xsi_mem_cmp(t56, t8, 128U);
    if (t58 == 1)
        goto LAB17;

LAB146:    t59 = (t1 + 19078);
    t61 = xsi_mem_cmp(t59, t8, 128U);
    if (t61 == 1)
        goto LAB18;

LAB147:    t62 = (t1 + 19206);
    t64 = xsi_mem_cmp(t62, t8, 128U);
    if (t64 == 1)
        goto LAB19;

LAB148:    t65 = (t1 + 19334);
    t67 = xsi_mem_cmp(t65, t8, 128U);
    if (t67 == 1)
        goto LAB20;

LAB149:    t68 = (t1 + 19462);
    t70 = xsi_mem_cmp(t68, t8, 128U);
    if (t70 == 1)
        goto LAB21;

LAB150:    t71 = (t1 + 19590);
    t73 = xsi_mem_cmp(t71, t8, 128U);
    if (t73 == 1)
        goto LAB22;

LAB151:    t74 = (t1 + 19718);
    t76 = xsi_mem_cmp(t74, t8, 128U);
    if (t76 == 1)
        goto LAB23;

LAB152:    t77 = (t1 + 19846);
    t79 = xsi_mem_cmp(t77, t8, 128U);
    if (t79 == 1)
        goto LAB24;

LAB153:    t80 = (t1 + 19974);
    t82 = xsi_mem_cmp(t80, t8, 128U);
    if (t82 == 1)
        goto LAB25;

LAB154:    t83 = (t1 + 20102);
    t85 = xsi_mem_cmp(t83, t8, 128U);
    if (t85 == 1)
        goto LAB26;

LAB155:    t86 = (t1 + 20230);
    t88 = xsi_mem_cmp(t86, t8, 128U);
    if (t88 == 1)
        goto LAB27;

LAB156:    t89 = (t1 + 20358);
    t91 = xsi_mem_cmp(t89, t8, 128U);
    if (t91 == 1)
        goto LAB28;

LAB157:    t92 = (t1 + 20486);
    t94 = xsi_mem_cmp(t92, t8, 128U);
    if (t94 == 1)
        goto LAB29;

LAB158:    t95 = (t1 + 20614);
    t97 = xsi_mem_cmp(t95, t8, 128U);
    if (t97 == 1)
        goto LAB30;

LAB159:    t98 = (t1 + 20742);
    t100 = xsi_mem_cmp(t98, t8, 128U);
    if (t100 == 1)
        goto LAB31;

LAB160:    t101 = (t1 + 20870);
    t103 = xsi_mem_cmp(t101, t8, 128U);
    if (t103 == 1)
        goto LAB32;

LAB161:    t104 = (t1 + 20998);
    t106 = xsi_mem_cmp(t104, t8, 128U);
    if (t106 == 1)
        goto LAB33;

LAB162:    t107 = (t1 + 21126);
    t109 = xsi_mem_cmp(t107, t8, 128U);
    if (t109 == 1)
        goto LAB34;

LAB163:    t110 = (t1 + 21254);
    t112 = xsi_mem_cmp(t110, t8, 128U);
    if (t112 == 1)
        goto LAB35;

LAB164:    t113 = (t1 + 21382);
    t115 = xsi_mem_cmp(t113, t8, 128U);
    if (t115 == 1)
        goto LAB36;

LAB165:    t116 = (t1 + 21510);
    t118 = xsi_mem_cmp(t116, t8, 128U);
    if (t118 == 1)
        goto LAB37;

LAB166:    t119 = (t1 + 21638);
    t121 = xsi_mem_cmp(t119, t8, 128U);
    if (t121 == 1)
        goto LAB38;

LAB167:    t122 = (t1 + 21766);
    t124 = xsi_mem_cmp(t122, t8, 128U);
    if (t124 == 1)
        goto LAB39;

LAB168:    t125 = (t1 + 21894);
    t127 = xsi_mem_cmp(t125, t8, 128U);
    if (t127 == 1)
        goto LAB40;

LAB169:    t128 = (t1 + 22022);
    t130 = xsi_mem_cmp(t128, t8, 128U);
    if (t130 == 1)
        goto LAB41;

LAB170:    t131 = (t1 + 22150);
    t133 = xsi_mem_cmp(t131, t8, 128U);
    if (t133 == 1)
        goto LAB42;

LAB171:    t134 = (t1 + 22278);
    t136 = xsi_mem_cmp(t134, t8, 128U);
    if (t136 == 1)
        goto LAB43;

LAB172:    t137 = (t1 + 22406);
    t139 = xsi_mem_cmp(t137, t8, 128U);
    if (t139 == 1)
        goto LAB44;

LAB173:    t140 = (t1 + 22534);
    t142 = xsi_mem_cmp(t140, t8, 128U);
    if (t142 == 1)
        goto LAB45;

LAB174:    t143 = (t1 + 22662);
    t145 = xsi_mem_cmp(t143, t8, 128U);
    if (t145 == 1)
        goto LAB46;

LAB175:    t146 = (t1 + 22790);
    t148 = xsi_mem_cmp(t146, t8, 128U);
    if (t148 == 1)
        goto LAB47;

LAB176:    t149 = (t1 + 22918);
    t151 = xsi_mem_cmp(t149, t8, 128U);
    if (t151 == 1)
        goto LAB48;

LAB177:    t152 = (t1 + 23046);
    t154 = xsi_mem_cmp(t152, t8, 128U);
    if (t154 == 1)
        goto LAB49;

LAB178:    t155 = (t1 + 23174);
    t157 = xsi_mem_cmp(t155, t8, 128U);
    if (t157 == 1)
        goto LAB50;

LAB179:    t158 = (t1 + 23302);
    t160 = xsi_mem_cmp(t158, t8, 128U);
    if (t160 == 1)
        goto LAB51;

LAB180:    t161 = (t1 + 23430);
    t163 = xsi_mem_cmp(t161, t8, 128U);
    if (t163 == 1)
        goto LAB52;

LAB181:    t164 = (t1 + 23558);
    t166 = xsi_mem_cmp(t164, t8, 128U);
    if (t166 == 1)
        goto LAB53;

LAB182:    t167 = (t1 + 23686);
    t169 = xsi_mem_cmp(t167, t8, 128U);
    if (t169 == 1)
        goto LAB54;

LAB183:    t170 = (t1 + 23814);
    t172 = xsi_mem_cmp(t170, t8, 128U);
    if (t172 == 1)
        goto LAB55;

LAB184:    t173 = (t1 + 23942);
    t175 = xsi_mem_cmp(t173, t8, 128U);
    if (t175 == 1)
        goto LAB56;

LAB185:    t176 = (t1 + 24070);
    t178 = xsi_mem_cmp(t176, t8, 128U);
    if (t178 == 1)
        goto LAB57;

LAB186:    t179 = (t1 + 24198);
    t181 = xsi_mem_cmp(t179, t8, 128U);
    if (t181 == 1)
        goto LAB58;

LAB187:    t182 = (t1 + 24326);
    t184 = xsi_mem_cmp(t182, t8, 128U);
    if (t184 == 1)
        goto LAB59;

LAB188:    t185 = (t1 + 24454);
    t187 = xsi_mem_cmp(t185, t8, 128U);
    if (t187 == 1)
        goto LAB60;

LAB189:    t188 = (t1 + 24582);
    t190 = xsi_mem_cmp(t188, t8, 128U);
    if (t190 == 1)
        goto LAB61;

LAB190:    t191 = (t1 + 24710);
    t193 = xsi_mem_cmp(t191, t8, 128U);
    if (t193 == 1)
        goto LAB62;

LAB191:    t194 = (t1 + 24838);
    t196 = xsi_mem_cmp(t194, t8, 128U);
    if (t196 == 1)
        goto LAB63;

LAB192:    t197 = (t1 + 24966);
    t199 = xsi_mem_cmp(t197, t8, 128U);
    if (t199 == 1)
        goto LAB64;

LAB193:    t200 = (t1 + 25094);
    t202 = xsi_mem_cmp(t200, t8, 128U);
    if (t202 == 1)
        goto LAB65;

LAB194:    t203 = (t1 + 25222);
    t205 = xsi_mem_cmp(t203, t8, 128U);
    if (t205 == 1)
        goto LAB66;

LAB195:    t206 = (t1 + 25350);
    t208 = xsi_mem_cmp(t206, t8, 128U);
    if (t208 == 1)
        goto LAB67;

LAB196:    t209 = (t1 + 25478);
    t211 = xsi_mem_cmp(t209, t8, 128U);
    if (t211 == 1)
        goto LAB68;

LAB197:    t212 = (t1 + 25606);
    t214 = xsi_mem_cmp(t212, t8, 128U);
    if (t214 == 1)
        goto LAB69;

LAB198:    t215 = (t1 + 25734);
    t217 = xsi_mem_cmp(t215, t8, 128U);
    if (t217 == 1)
        goto LAB70;

LAB199:    t218 = (t1 + 25862);
    t220 = xsi_mem_cmp(t218, t8, 128U);
    if (t220 == 1)
        goto LAB71;

LAB200:    t221 = (t1 + 25990);
    t223 = xsi_mem_cmp(t221, t8, 128U);
    if (t223 == 1)
        goto LAB72;

LAB201:    t224 = (t1 + 26118);
    t226 = xsi_mem_cmp(t224, t8, 128U);
    if (t226 == 1)
        goto LAB73;

LAB202:    t227 = (t1 + 26246);
    t229 = xsi_mem_cmp(t227, t8, 128U);
    if (t229 == 1)
        goto LAB74;

LAB203:    t230 = (t1 + 26374);
    t232 = xsi_mem_cmp(t230, t8, 128U);
    if (t232 == 1)
        goto LAB75;

LAB204:    t233 = (t1 + 26502);
    t235 = xsi_mem_cmp(t233, t8, 128U);
    if (t235 == 1)
        goto LAB76;

LAB205:    t236 = (t1 + 26630);
    t238 = xsi_mem_cmp(t236, t8, 128U);
    if (t238 == 1)
        goto LAB77;

LAB206:    t239 = (t1 + 26758);
    t241 = xsi_mem_cmp(t239, t8, 128U);
    if (t241 == 1)
        goto LAB78;

LAB207:    t242 = (t1 + 26886);
    t244 = xsi_mem_cmp(t242, t8, 128U);
    if (t244 == 1)
        goto LAB79;

LAB208:    t245 = (t1 + 27014);
    t247 = xsi_mem_cmp(t245, t8, 128U);
    if (t247 == 1)
        goto LAB80;

LAB209:    t248 = (t1 + 27142);
    t250 = xsi_mem_cmp(t248, t8, 128U);
    if (t250 == 1)
        goto LAB81;

LAB210:    t251 = (t1 + 27270);
    t253 = xsi_mem_cmp(t251, t8, 128U);
    if (t253 == 1)
        goto LAB82;

LAB211:    t254 = (t1 + 27398);
    t256 = xsi_mem_cmp(t254, t8, 128U);
    if (t256 == 1)
        goto LAB83;

LAB212:    t257 = (t1 + 27526);
    t259 = xsi_mem_cmp(t257, t8, 128U);
    if (t259 == 1)
        goto LAB84;

LAB213:    t260 = (t1 + 27654);
    t262 = xsi_mem_cmp(t260, t8, 128U);
    if (t262 == 1)
        goto LAB85;

LAB214:    t263 = (t1 + 27782);
    t265 = xsi_mem_cmp(t263, t8, 128U);
    if (t265 == 1)
        goto LAB86;

LAB215:    t266 = (t1 + 27910);
    t268 = xsi_mem_cmp(t266, t8, 128U);
    if (t268 == 1)
        goto LAB87;

LAB216:    t269 = (t1 + 28038);
    t271 = xsi_mem_cmp(t269, t8, 128U);
    if (t271 == 1)
        goto LAB88;

LAB217:    t272 = (t1 + 28166);
    t274 = xsi_mem_cmp(t272, t8, 128U);
    if (t274 == 1)
        goto LAB89;

LAB218:    t275 = (t1 + 28294);
    t277 = xsi_mem_cmp(t275, t8, 128U);
    if (t277 == 1)
        goto LAB90;

LAB219:    t278 = (t1 + 28422);
    t280 = xsi_mem_cmp(t278, t8, 128U);
    if (t280 == 1)
        goto LAB91;

LAB220:    t281 = (t1 + 28550);
    t283 = xsi_mem_cmp(t281, t8, 128U);
    if (t283 == 1)
        goto LAB92;

LAB221:    t284 = (t1 + 28678);
    t286 = xsi_mem_cmp(t284, t8, 128U);
    if (t286 == 1)
        goto LAB93;

LAB222:    t287 = (t1 + 28806);
    t289 = xsi_mem_cmp(t287, t8, 128U);
    if (t289 == 1)
        goto LAB94;

LAB223:    t290 = (t1 + 28934);
    t292 = xsi_mem_cmp(t290, t8, 128U);
    if (t292 == 1)
        goto LAB95;

LAB224:    t293 = (t1 + 29062);
    t295 = xsi_mem_cmp(t293, t8, 128U);
    if (t295 == 1)
        goto LAB96;

LAB225:    t296 = (t1 + 29190);
    t298 = xsi_mem_cmp(t296, t8, 128U);
    if (t298 == 1)
        goto LAB97;

LAB226:    t299 = (t1 + 29318);
    t301 = xsi_mem_cmp(t299, t8, 128U);
    if (t301 == 1)
        goto LAB98;

LAB227:    t302 = (t1 + 29446);
    t304 = xsi_mem_cmp(t302, t8, 128U);
    if (t304 == 1)
        goto LAB99;

LAB228:    t305 = (t1 + 29574);
    t307 = xsi_mem_cmp(t305, t8, 128U);
    if (t307 == 1)
        goto LAB100;

LAB229:    t308 = (t1 + 29702);
    t310 = xsi_mem_cmp(t308, t8, 128U);
    if (t310 == 1)
        goto LAB101;

LAB230:    t311 = (t1 + 29830);
    t313 = xsi_mem_cmp(t311, t8, 128U);
    if (t313 == 1)
        goto LAB102;

LAB231:    t314 = (t1 + 29958);
    t316 = xsi_mem_cmp(t314, t8, 128U);
    if (t316 == 1)
        goto LAB103;

LAB232:    t317 = (t1 + 30086);
    t319 = xsi_mem_cmp(t317, t8, 128U);
    if (t319 == 1)
        goto LAB104;

LAB233:    t320 = (t1 + 30214);
    t322 = xsi_mem_cmp(t320, t8, 128U);
    if (t322 == 1)
        goto LAB105;

LAB234:    t323 = (t1 + 30342);
    t325 = xsi_mem_cmp(t323, t8, 128U);
    if (t325 == 1)
        goto LAB106;

LAB235:    t326 = (t1 + 30470);
    t328 = xsi_mem_cmp(t326, t8, 128U);
    if (t328 == 1)
        goto LAB107;

LAB236:    t329 = (t1 + 30598);
    t331 = xsi_mem_cmp(t329, t8, 128U);
    if (t331 == 1)
        goto LAB108;

LAB237:    t332 = (t1 + 30726);
    t334 = xsi_mem_cmp(t332, t8, 128U);
    if (t334 == 1)
        goto LAB109;

LAB238:    t335 = (t1 + 30854);
    t337 = xsi_mem_cmp(t335, t8, 128U);
    if (t337 == 1)
        goto LAB110;

LAB239:    t338 = (t1 + 30982);
    t340 = xsi_mem_cmp(t338, t8, 128U);
    if (t340 == 1)
        goto LAB111;

LAB240:    t341 = (t1 + 31110);
    t343 = xsi_mem_cmp(t341, t8, 128U);
    if (t343 == 1)
        goto LAB112;

LAB241:    t344 = (t1 + 31238);
    t346 = xsi_mem_cmp(t344, t8, 128U);
    if (t346 == 1)
        goto LAB113;

LAB242:    t347 = (t1 + 31366);
    t349 = xsi_mem_cmp(t347, t8, 128U);
    if (t349 == 1)
        goto LAB114;

LAB243:    t350 = (t1 + 31494);
    t352 = xsi_mem_cmp(t350, t8, 128U);
    if (t352 == 1)
        goto LAB115;

LAB244:    t353 = (t1 + 31622);
    t355 = xsi_mem_cmp(t353, t8, 128U);
    if (t355 == 1)
        goto LAB116;

LAB245:    t356 = (t1 + 31750);
    t358 = xsi_mem_cmp(t356, t8, 128U);
    if (t358 == 1)
        goto LAB117;

LAB246:    t359 = (t1 + 31878);
    t361 = xsi_mem_cmp(t359, t8, 128U);
    if (t361 == 1)
        goto LAB118;

LAB247:    t362 = (t1 + 32006);
    t364 = xsi_mem_cmp(t362, t8, 128U);
    if (t364 == 1)
        goto LAB119;

LAB248:    t365 = (t1 + 32134);
    t367 = xsi_mem_cmp(t365, t8, 128U);
    if (t367 == 1)
        goto LAB120;

LAB249:    t368 = (t1 + 32262);
    t370 = xsi_mem_cmp(t368, t8, 128U);
    if (t370 == 1)
        goto LAB121;

LAB250:    t371 = (t1 + 32390);
    t373 = xsi_mem_cmp(t371, t8, 128U);
    if (t373 == 1)
        goto LAB122;

LAB251:    t374 = (t1 + 32518);
    t376 = xsi_mem_cmp(t374, t8, 128U);
    if (t376 == 1)
        goto LAB123;

LAB252:    t377 = (t1 + 32646);
    t379 = xsi_mem_cmp(t377, t8, 128U);
    if (t379 == 1)
        goto LAB124;

LAB253:    t380 = (t1 + 32774);
    t382 = xsi_mem_cmp(t380, t8, 128U);
    if (t382 == 1)
        goto LAB125;

LAB254:    t383 = (t1 + 32902);
    t385 = xsi_mem_cmp(t383, t8, 128U);
    if (t385 == 1)
        goto LAB126;

LAB255:    t386 = (t1 + 33030);
    t388 = xsi_mem_cmp(t386, t8, 128U);
    if (t388 == 1)
        goto LAB127;

LAB256:    t389 = (t1 + 33158);
    t391 = xsi_mem_cmp(t389, t8, 128U);
    if (t391 == 1)
        goto LAB128;

LAB257:    t392 = (t1 + 33286);
    t394 = xsi_mem_cmp(t392, t8, 128U);
    if (t394 == 1)
        goto LAB129;

LAB258:    t395 = (t1 + 33414);
    t397 = xsi_mem_cmp(t395, t8, 128U);
    if (t397 == 1)
        goto LAB130;

LAB259:    t398 = (t1 + 33542);
    t400 = xsi_mem_cmp(t398, t8, 128U);
    if (t400 == 1)
        goto LAB131;

LAB260:    t401 = (t1 + 33670);
    t403 = xsi_mem_cmp(t401, t8, 128U);
    if (t403 == 1)
        goto LAB132;

LAB261:
LAB133:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 128;

LAB4:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t15 = *((int *)t8);
    t0 = t15;

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB5:    t404 = (t6 + 56U);
    t405 = *((char **)t404);
    t404 = (t405 + 0);
    *((int *)t404) = 0;
    goto LAB4;

LAB6:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 1;
    goto LAB4;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 2;
    goto LAB4;

LAB8:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 3;
    goto LAB4;

LAB9:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 4;
    goto LAB4;

LAB10:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 5;
    goto LAB4;

LAB11:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 6;
    goto LAB4;

LAB12:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 7;
    goto LAB4;

LAB13:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 8;
    goto LAB4;

LAB14:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 9;
    goto LAB4;

LAB15:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 10;
    goto LAB4;

LAB16:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 11;
    goto LAB4;

LAB17:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 12;
    goto LAB4;

LAB18:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 13;
    goto LAB4;

LAB19:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 14;
    goto LAB4;

LAB20:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 15;
    goto LAB4;

LAB21:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 16;
    goto LAB4;

LAB22:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 17;
    goto LAB4;

LAB23:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 18;
    goto LAB4;

LAB24:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 19;
    goto LAB4;

LAB25:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 20;
    goto LAB4;

LAB26:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 21;
    goto LAB4;

LAB27:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 22;
    goto LAB4;

LAB28:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 23;
    goto LAB4;

LAB29:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 24;
    goto LAB4;

LAB30:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 25;
    goto LAB4;

LAB31:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 26;
    goto LAB4;

LAB32:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 27;
    goto LAB4;

LAB33:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 28;
    goto LAB4;

LAB34:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 29;
    goto LAB4;

LAB35:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 30;
    goto LAB4;

LAB36:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 31;
    goto LAB4;

LAB37:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 32;
    goto LAB4;

LAB38:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 33;
    goto LAB4;

LAB39:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 34;
    goto LAB4;

LAB40:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 35;
    goto LAB4;

LAB41:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 36;
    goto LAB4;

LAB42:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 37;
    goto LAB4;

LAB43:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 38;
    goto LAB4;

LAB44:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 39;
    goto LAB4;

LAB45:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 40;
    goto LAB4;

LAB46:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 41;
    goto LAB4;

LAB47:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 42;
    goto LAB4;

LAB48:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 43;
    goto LAB4;

LAB49:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 44;
    goto LAB4;

LAB50:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 45;
    goto LAB4;

LAB51:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 46;
    goto LAB4;

LAB52:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 47;
    goto LAB4;

LAB53:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 48;
    goto LAB4;

LAB54:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 49;
    goto LAB4;

LAB55:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 50;
    goto LAB4;

LAB56:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 51;
    goto LAB4;

LAB57:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 52;
    goto LAB4;

LAB58:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 53;
    goto LAB4;

LAB59:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 54;
    goto LAB4;

LAB60:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 55;
    goto LAB4;

LAB61:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 56;
    goto LAB4;

LAB62:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 57;
    goto LAB4;

LAB63:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 58;
    goto LAB4;

LAB64:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 59;
    goto LAB4;

LAB65:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 60;
    goto LAB4;

LAB66:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 61;
    goto LAB4;

LAB67:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 62;
    goto LAB4;

LAB68:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 63;
    goto LAB4;

LAB69:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 64;
    goto LAB4;

LAB70:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 65;
    goto LAB4;

LAB71:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 66;
    goto LAB4;

LAB72:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 67;
    goto LAB4;

LAB73:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 68;
    goto LAB4;

LAB74:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 69;
    goto LAB4;

LAB75:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 70;
    goto LAB4;

LAB76:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 71;
    goto LAB4;

LAB77:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 72;
    goto LAB4;

LAB78:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 73;
    goto LAB4;

LAB79:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 74;
    goto LAB4;

LAB80:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 75;
    goto LAB4;

LAB81:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 76;
    goto LAB4;

LAB82:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 77;
    goto LAB4;

LAB83:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 78;
    goto LAB4;

LAB84:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 79;
    goto LAB4;

LAB85:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 80;
    goto LAB4;

LAB86:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 81;
    goto LAB4;

LAB87:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 82;
    goto LAB4;

LAB88:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 83;
    goto LAB4;

LAB89:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 84;
    goto LAB4;

LAB90:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 85;
    goto LAB4;

LAB91:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 86;
    goto LAB4;

LAB92:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 87;
    goto LAB4;

LAB93:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 88;
    goto LAB4;

LAB94:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 89;
    goto LAB4;

LAB95:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 90;
    goto LAB4;

LAB96:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 91;
    goto LAB4;

LAB97:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 92;
    goto LAB4;

LAB98:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 93;
    goto LAB4;

LAB99:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 94;
    goto LAB4;

LAB100:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 95;
    goto LAB4;

LAB101:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 96;
    goto LAB4;

LAB102:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 97;
    goto LAB4;

LAB103:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 98;
    goto LAB4;

LAB104:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 99;
    goto LAB4;

LAB105:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 100;
    goto LAB4;

LAB106:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 101;
    goto LAB4;

LAB107:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 102;
    goto LAB4;

LAB108:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 103;
    goto LAB4;

LAB109:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 104;
    goto LAB4;

LAB110:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 105;
    goto LAB4;

LAB111:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 106;
    goto LAB4;

LAB112:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 107;
    goto LAB4;

LAB113:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 108;
    goto LAB4;

LAB114:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 109;
    goto LAB4;

LAB115:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 110;
    goto LAB4;

LAB116:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 111;
    goto LAB4;

LAB117:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 112;
    goto LAB4;

LAB118:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 113;
    goto LAB4;

LAB119:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 114;
    goto LAB4;

LAB120:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 115;
    goto LAB4;

LAB121:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 116;
    goto LAB4;

LAB122:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 117;
    goto LAB4;

LAB123:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 118;
    goto LAB4;

LAB124:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 119;
    goto LAB4;

LAB125:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 120;
    goto LAB4;

LAB126:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 121;
    goto LAB4;

LAB127:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 122;
    goto LAB4;

LAB128:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 123;
    goto LAB4;

LAB129:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 124;
    goto LAB4;

LAB130:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 125;
    goto LAB4;

LAB131:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 126;
    goto LAB4;

LAB132:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((int *)t7) = 127;
    goto LAB4;

LAB262:;
LAB263:;
}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(963, ng2);

LAB3:    t1 = (t0 + 1936U);
    t2 = *((char **)t1);
    t1 = (t0 + 6584);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 1U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 6392);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(967, ng2);

LAB3:    t1 = (t0 + 1296U);
    t2 = *((char **)t1);
    t1 = (t0 + 6648);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast(t1);

LAB2:    t7 = (t0 + 6408);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(970, ng2);

LAB3:    t1 = (t0 + 2096U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6712);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 6424);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_3(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(978, ng2);

LAB3:    t1 = (t0 + 2256U);
    t2 = *((char **)t1);
    t3 = (1 - 1);
    t4 = (7 - t3);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = (t0 + 6776);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 1U);
    xsi_driver_first_trans_fast(t7);

LAB2:    t12 = (t0 + 6440);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_4(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(984, ng2);

LAB3:    t1 = (t0 + 1936U);
    t2 = *((char **)t1);
    t1 = (t0 + 11812U);
    t3 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t2, t1);
    t4 = (t0 + 6840);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((int *)t8) = t3;
    xsi_driver_first_trans_fast(t4);

LAB2:    t9 = (t0 + 6456);
    *((int *)t9) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_5(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    char *t4;
    int t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(987, ng2);
    t1 = (t0 + 2416U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    t1 = (t0 + 3112U);
    t4 = *((char **)t1);
    t5 = *((int *)t4);
    t6 = (t3 >= t5);
    if (t6 != 0)
        goto LAB3;

LAB4:
LAB5:    t11 = (t0 + 6904);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)2;
    xsi_driver_first_trans_fast(t11);

LAB2:    t16 = (t0 + 6472);
    *((int *)t16) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 6904);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_6(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(1049, ng2);

LAB3:    t1 = (t0 + 1776U);
    t2 = *((char **)t1);
    t1 = (t0 + 11796U);
    t3 = axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877951117_2560086426(t0, t2, t1);
    t4 = (t0 + 6968);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((int *)t8) = t3;
    xsi_driver_first_trans_fast(t4);

LAB2:    t9 = (t0 + 6488);
    *((int *)t9) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_datamover_v4_02_a_a_1215259340_3640575771_p_7(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    int t4;
    char *t5;
    int t6;
    char *t7;
    unsigned int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(1051, ng2);

LAB3:    t2 = (t0 + 2576U);
    t3 = *((char **)t2);
    t4 = *((int *)t3);
    t2 = (t0 + 3352U);
    t5 = *((char **)t2);
    t6 = *((int *)t5);
    t2 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t1, t4, t6);
    t7 = (t1 + 12U);
    t8 = *((unsigned int *)t7);
    t8 = (t8 * 1U);
    t9 = (8U != t8);
    if (t9 == 1)
        goto LAB5;

LAB6:    t10 = (t0 + 7032);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast(t10);

LAB2:    t15 = (t0 + 6504);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t8, 0);
    goto LAB6;

}


extern void axi_datamover_v4_02_a_a_1215259340_3640575771_init()
{
	static char *pe[] = {(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_0,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_1,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_2,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_3,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_4,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_5,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_6,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_p_7};
	static char *se[] = {(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877951117_2560086426,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877953295_2560086426,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_877957651_2560086426,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_1565228898_2560086426,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_1565296416_2560086426,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_1565406405_2560086426,(void *)axi_datamover_v4_02_a_a_1215259340_3640575771_sub_2770453558_2560086426};
	xsi_register_didat("axi_datamover_v4_02_a_a_1215259340_3640575771", "isim/module_1_stub.exe.sim/axi_datamover_v4_02_a/a_1215259340_3640575771.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
