/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/xilinx/14.7/ISE_DS/EDK/hw/XilinxProcessorIPLib/pcores/axi_iic_v1_02_a/hdl/vhdl/iic_control.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void axi_iic_v1_02_a_a_0123855902_1516540902_p_0(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(385, ng0);
    t4 = (t0 + 9560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)2);
    if (t7 == 1)
        goto LAB11;

LAB12:    t4 = (t0 + 4440U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    t3 = t10;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t4 = (t0 + 11480U);
    t11 = *((char **)t4);
    t12 = *((unsigned char *)t11);
    t13 = (t12 == (unsigned char)3);
    t2 = t13;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t4 = (t0 + 20440U);
    t14 = *((char **)t4);
    t15 = *((unsigned char *)t14);
    t16 = (t15 == (unsigned char)3);
    t1 = t16;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB14:    t21 = (t0 + 45864);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    *((unsigned char *)t25) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t21);

LAB2:    t26 = (t0 + 44744);
    *((int *)t26) = 1;

LAB1:    return;
LAB3:    t4 = (t0 + 45864);
    t17 = (t4 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t4);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t2 = (unsigned char)1;
    goto LAB10;

LAB11:    t3 = (unsigned char)1;
    goto LAB13;

LAB15:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    xsi_set_current_line(395, ng0);

LAB3:    t1 = (t0 + 45928);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_2(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    xsi_set_current_line(400, ng0);
    t5 = (t0 + 12920U);
    t6 = *((char **)t5);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)3);
    if (t8 == 1)
        goto LAB14;

LAB15:    t4 = (unsigned char)0;

LAB16:    if (t4 == 1)
        goto LAB11;

LAB12:    t3 = (unsigned char)0;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t5 = (t0 + 12920U);
    t16 = *((char **)t5);
    t17 = *((unsigned char *)t16);
    t18 = (t17 == (unsigned char)2);
    if (t18 == 1)
        goto LAB17;

LAB18:    t15 = (unsigned char)0;

LAB19:    t2 = t15;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t5 = (t0 + 16760U);
    t22 = *((char **)t5);
    t23 = *((unsigned char *)t22);
    t24 = (t23 == (unsigned char)3);
    t1 = t24;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB20:    t29 = (t0 + 45992);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t29);

LAB2:    t34 = (t0 + 44760);
    *((int *)t34) = 1;

LAB1:    return;
LAB3:    t5 = (t0 + 45992);
    t25 = (t5 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    *((unsigned char *)t28) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t5);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t2 = (unsigned char)1;
    goto LAB10;

LAB11:    t5 = (t0 + 11960U);
    t12 = *((char **)t5);
    t13 = *((unsigned char *)t12);
    t14 = (t13 == (unsigned char)2);
    t3 = t14;
    goto LAB13;

LAB14:    t5 = (t0 + 14680U);
    t9 = *((char **)t5);
    t10 = *((unsigned char *)t9);
    t11 = (t10 == (unsigned char)2);
    t4 = t11;
    goto LAB16;

LAB17:    t5 = (t0 + 12440U);
    t19 = *((char **)t5);
    t20 = *((unsigned char *)t19);
    t21 = (t20 == (unsigned char)2);
    t15 = t21;
    goto LAB19;

LAB21:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    xsi_set_current_line(406, ng0);

LAB3:    t1 = (t0 + 46056);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    xsi_set_current_line(411, ng0);

LAB3:    t1 = (t0 + 24616U);
    t2 = *((char **)t1);
    t1 = (t0 + 46120);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_5(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(412, ng0);

LAB3:    t1 = (t0 + 25096U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 46184);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_6(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    xsi_set_current_line(413, ng0);

LAB3:    t1 = (t0 + 24976U);
    t2 = *((char **)t1);
    t1 = (t0 + 46248);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 10U);
    xsi_driver_first_trans_fast(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_7(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    xsi_set_current_line(414, ng0);

LAB3:    t1 = (t0 + 24736U);
    t2 = *((char **)t1);
    t1 = (t0 + 46312);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_8(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(425, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 44776);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(426, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(433, ng0);
    t2 = (t0 + 5240U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 46376);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(434, ng0);
    t2 = (t0 + 4600U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 46440);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(435, ng0);
    t2 = (t0 + 4440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 46504);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(436, ng0);
    t2 = (t0 + 16280U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 46568);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(437, ng0);
    t2 = (t0 + 20280U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 46632);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(427, ng0);
    t4 = (t0 + 46376);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(428, ng0);
    t2 = (t0 + 46440);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(429, ng0);
    t2 = (t0 + 46504);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(430, ng0);
    t2 = (t0 + 46568);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(431, ng0);
    t2 = (t0 + 46632);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_9(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(442, ng0);

LAB3:    t1 = (t0 + 22840U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20280U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t6);
    t1 = (t0 + 46696);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast(t1);

LAB2:    t12 = (t0 + 44792);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_10(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(443, ng0);

LAB3:    t1 = (t0 + 5240U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20600U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t6);
    t1 = (t0 + 46760);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast(t1);

LAB2:    t12 = (t0 + 44808);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_11(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(444, ng0);

LAB3:    t1 = (t0 + 16280U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 23320U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t6);
    t1 = (t0 + 46824);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast(t1);

LAB2:    t12 = (t0 + 44824);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_12(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;

LAB0:    xsi_set_current_line(454, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 44840);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(455, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 5240U);
    t4 = *((char **)t2);
    t6 = *((unsigned char *)t4);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 4600U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)2);
    if (t6 == 1)
        goto LAB21;

LAB22:    t1 = (unsigned char)0;

LAB23:    if (t1 != 0)
        goto LAB19;

LAB20:    xsi_set_current_line(462, ng0);
    t2 = (t0 + 20440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 46888);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(456, ng0);
    t4 = (t0 + 46888);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(458, ng0);
    t2 = (t0 + 46888);
    t10 = (t2 + 56U);
    t13 = *((char **)t10);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t2 = (t0 + 4600U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)3);
    t1 = t17;
    goto LAB15;

LAB16:    t2 = (t0 + 20600U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)2);
    t3 = t11;
    goto LAB18;

LAB19:    xsi_set_current_line(460, ng0);
    t2 = (t0 + 46888);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB21:    t2 = (t0 + 20760U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)3);
    t1 = t9;
    goto LAB23;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_13(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    unsigned char t29;
    unsigned char t30;
    unsigned char t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    unsigned char t35;
    unsigned char t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;

LAB0:    xsi_set_current_line(476, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 44856);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(477, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 4600U);
    t4 = *((char **)t2);
    t9 = *((unsigned char *)t4);
    t11 = (t9 == (unsigned char)3);
    if (t11 == 1)
        goto LAB22;

LAB23:    t7 = (unsigned char)0;

LAB24:    if (t7 == 1)
        goto LAB19;

LAB20:    t6 = (unsigned char)0;

LAB21:    if (t6 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t6 = *((unsigned char *)t4);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB42;

LAB43:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)0);
    t3 = t11;

LAB44:    if (t3 == 1)
        goto LAB39;

LAB40:    t2 = (t0 + 4600U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)2);
    t1 = t17;

LAB41:    if (t1 != 0)
        goto LAB37;

LAB38:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(478, ng0);
    t4 = (t0 + 46952);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(483, ng0);
    t2 = (t0 + 46952);
    t37 = (t2 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t2 = (t0 + 18840U);
    t14 = *((char **)t2);
    t27 = *((unsigned char *)t14);
    t28 = (t27 == (unsigned char)2);
    if (t28 == 1)
        goto LAB31;

LAB32:    t26 = (unsigned char)0;

LAB33:    if (t26 == 1)
        goto LAB28;

LAB29:    t2 = (t0 + 18840U);
    t16 = *((char **)t2);
    t32 = *((unsigned char *)t16);
    t33 = (t32 == (unsigned char)3);
    if (t33 == 1)
        goto LAB34;

LAB35:    t31 = (unsigned char)0;

LAB36:    t25 = t31;

LAB30:    t1 = t25;
    goto LAB15;

LAB16:    t2 = (t0 + 16280U);
    t13 = *((char **)t2);
    t23 = *((unsigned char *)t13);
    t24 = (t23 == (unsigned char)2);
    t3 = t24;
    goto LAB18;

LAB19:    t2 = (t0 + 9880U);
    t10 = *((char **)t2);
    t21 = *((unsigned char *)t10);
    t22 = (t21 == (unsigned char)3);
    t6 = t22;
    goto LAB21;

LAB22:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t17 = *((unsigned char *)t5);
    t18 = (t17 == (unsigned char)6);
    if (t18 == 1)
        goto LAB25;

LAB26:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t19 = *((unsigned char *)t8);
    t20 = (t19 == (unsigned char)2);
    t12 = t20;

LAB27:    t7 = t12;
    goto LAB24;

LAB25:    t12 = (unsigned char)1;
    goto LAB27;

LAB28:    t25 = (unsigned char)1;
    goto LAB30;

LAB31:    t2 = (t0 + 19000U);
    t15 = *((char **)t2);
    t29 = *((unsigned char *)t15);
    t30 = (t29 == (unsigned char)2);
    t26 = t30;
    goto LAB33;

LAB34:    t2 = (t0 + 19000U);
    t34 = *((char **)t2);
    t35 = *((unsigned char *)t34);
    t36 = (t35 == (unsigned char)3);
    t31 = t36;
    goto LAB36;

LAB37:    xsi_set_current_line(485, ng0);
    t2 = (t0 + 46952);
    t10 = (t2 + 56U);
    t13 = *((char **)t10);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB39:    t1 = (unsigned char)1;
    goto LAB41;

LAB42:    t3 = (unsigned char)1;
    goto LAB44;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_14(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(490, ng0);

LAB3:    t1 = (t0 + 20280U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 47016);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 44872);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_15(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned int t18;

LAB0:    xsi_set_current_line(527, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 44888);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(528, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 11320U);
    t4 = *((char **)t2);
    t6 = *((unsigned char *)t4);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 20280U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)3);
    t3 = t11;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 11640U);
    t4 = *((char **)t2);
    t2 = (t0 + 3320U);
    t5 = *((char **)t2);
    t1 = 1;
    if (10U == 10U)
        goto LAB21;

LAB22:    t1 = 0;

LAB23:    if (t1 != 0)
        goto LAB19;

LAB20:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(529, ng0);
    t4 = (t0 + 47080);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(538, ng0);
    t2 = (t0 + 47080);
    t10 = (t2 + 56U);
    t13 = *((char **)t10);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t2 = (t0 + 8920U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)2);
    t1 = t17;
    goto LAB15;

LAB16:    t3 = (unsigned char)1;
    goto LAB18;

LAB19:    xsi_set_current_line(540, ng0);
    t10 = (t0 + 47080);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t10);
    goto LAB9;

LAB21:    t18 = 0;

LAB24:    if (t18 < 10U)
        goto LAB25;
    else
        goto LAB23;

LAB25:    t2 = (t4 + t18);
    t8 = (t5 + t18);
    if (*((unsigned char *)t2) != *((unsigned char *)t8))
        goto LAB22;

LAB26:    t18 = (t18 + 1);
    goto LAB24;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_16(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(557, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 44904);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(558, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8600U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)0);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8600U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)8);
    t1 = t9;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB16;

LAB17:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(559, ng0);
    t4 = (t0 + 47144);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(560, ng0);
    t2 = (t0 + 47208);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB11:    xsi_set_current_line(562, ng0);
    t2 = (t0 + 47144);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(563, ng0);
    t2 = (t0 + 47208);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    xsi_set_current_line(567, ng0);
    t2 = (t0 + 9720U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)3);
    if (t9 == 1)
        goto LAB21;

LAB22:    t6 = (unsigned char)0;

LAB23:    if (t6 != 0)
        goto LAB18;

LAB20:    xsi_set_current_line(580, ng0);
    t2 = (t0 + 47208);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB19:    goto LAB9;

LAB18:    xsi_set_current_line(569, ng0);
    t2 = (t0 + 11960U);
    t13 = *((char **)t2);
    t21 = *((unsigned char *)t13);
    t22 = (t21 == (unsigned char)3);
    if (t22 == 1)
        goto LAB30;

LAB31:    t20 = (unsigned char)0;

LAB32:    if (t20 != 0)
        goto LAB27;

LAB29:    xsi_set_current_line(576, ng0);
    t2 = (t0 + 47144);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(577, ng0);
    t2 = (t0 + 47208);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB28:    goto LAB19;

LAB21:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)1);
    if (t17 == 1)
        goto LAB24;

LAB25:    t2 = (t0 + 8440U);
    t10 = *((char **)t2);
    t18 = *((unsigned char *)t10);
    t19 = (t18 == (unsigned char)5);
    t11 = t19;

LAB26:    t6 = t11;
    goto LAB23;

LAB24:    t11 = (unsigned char)1;
    goto LAB26;

LAB27:    xsi_set_current_line(573, ng0);
    t2 = (t0 + 47144);
    t15 = (t2 + 56U);
    t16 = *((char **)t15);
    t25 = (t16 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(574, ng0);
    t2 = (t0 + 47208);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB28;

LAB30:    t2 = (t0 + 10520U);
    t14 = *((char **)t2);
    t23 = *((unsigned char *)t14);
    t24 = (t23 == (unsigned char)2);
    t20 = t24;
    goto LAB32;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_17(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(587, ng0);

LAB3:    t1 = (t0 + 15160U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 15640U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t5);
    t1 = (t0 + 47272);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t6;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t11 = (t0 + 44920);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_18(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5, &&LAB6, &&LAB7, &&LAB8, &&LAB9, &&LAB10, &&LAB11};

LAB0:    xsi_set_current_line(626, ng0);
    t1 = (t0 + 47336);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(627, ng0);
    t1 = (t0 + 11960U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (t0 + 47400);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = t6;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(628, ng0);
    t1 = (t0 + 16760U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (t0 + 47464);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = t6;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(629, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(630, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(631, ng0);
    t1 = (t0 + 8600U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (t0 + 47656);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = t6;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(632, ng0);
    t1 = (t0 + 25216U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (t0 + 47720);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = t6;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(634, ng0);
    t1 = (t0 + 8600U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t6);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 44936);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(637, ng0);
    t3 = (t0 + 47400);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(638, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(640, ng0);
    t1 = (t0 + 12920U);
    t2 = *((char **)t1);
    t10 = *((unsigned char *)t2);
    t11 = (t10 == (unsigned char)3);
    if (t11 == 1)
        goto LAB19;

LAB20:    t9 = (unsigned char)0;

LAB21:    if (t9 == 1)
        goto LAB16;

LAB17:    t6 = (unsigned char)0;

LAB18:    if (t6 != 0)
        goto LAB13;

LAB15:    xsi_set_current_line(643, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB14:    goto LAB2;

LAB4:    xsi_set_current_line(648, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(649, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(650, ng0);
    t1 = (t0 + 47400);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(651, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(652, ng0);
    t1 = (t0 + 10520U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)2);
    if (t9 != 0)
        goto LAB22;

LAB24:    xsi_set_current_line(655, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);

LAB23:    goto LAB2;

LAB5:    xsi_set_current_line(663, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(664, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(666, ng0);
    t1 = (t0 + 16440U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB25;

LAB27:
LAB26:    xsi_set_current_line(670, ng0);
    t1 = (t0 + 17560U);
    t2 = *((char **)t1);
    t1 = (t0 + 3160U);
    t3 = *((char **)t1);
    t6 = 1;
    if (10U == 10U)
        goto LAB31;

LAB32:    t6 = 0;

LAB33:    if (t6 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(673, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB29:    goto LAB2;

LAB6:    xsi_set_current_line(677, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(678, ng0);
    t1 = (t0 + 47336);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(679, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(680, ng0);
    t1 = (t0 + 8920U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)2);
    if (t9 != 0)
        goto LAB37;

LAB39:
LAB38:    xsi_set_current_line(684, ng0);
    t1 = (t0 + 8920U);
    t2 = *((char **)t1);
    t9 = *((unsigned char *)t2);
    t10 = (t9 == (unsigned char)2);
    if (t10 == 1)
        goto LAB43;

LAB44:    t6 = (unsigned char)0;

LAB45:    if (t6 != 0)
        goto LAB40;

LAB42:    xsi_set_current_line(693, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB41:    goto LAB2;

LAB7:    xsi_set_current_line(697, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(698, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(699, ng0);
    t1 = (t0 + 47336);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(700, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(705, ng0);
    t1 = (t0 + 15640U);
    t2 = *((char **)t1);
    t12 = *((unsigned char *)t2);
    t13 = (t12 == (unsigned char)3);
    if (t13 == 1)
        goto LAB64;

LAB65:    t1 = (t0 + 16280U);
    t3 = *((char **)t1);
    t14 = *((unsigned char *)t3);
    t15 = (t14 == (unsigned char)3);
    t11 = t15;

LAB66:    if (t11 == 1)
        goto LAB61;

LAB62:    t10 = (unsigned char)0;

LAB63:    if (t10 == 1)
        goto LAB58;

LAB59:    t9 = (unsigned char)0;

LAB60:    if (t9 == 1)
        goto LAB55;

LAB56:    t6 = (unsigned char)0;

LAB57:    if (t6 != 0)
        goto LAB52;

LAB54:    t1 = (t0 + 16440U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB67;

LAB68:    xsi_set_current_line(718, ng0);
    t1 = (t0 + 12600U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (t0 + 47400);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = t6;
    xsi_driver_first_trans_fast(t1);

LAB53:    xsi_set_current_line(727, ng0);
    t1 = (t0 + 17560U);
    t2 = *((char **)t1);
    t1 = (t0 + 3800U);
    t3 = *((char **)t1);
    t6 = 1;
    if (10U == 10U)
        goto LAB72;

LAB73:    t6 = 0;

LAB74:    if (t6 != 0)
        goto LAB69;

LAB71:    xsi_set_current_line(730, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)4;
    xsi_driver_first_trans_fast(t1);

LAB70:    goto LAB2;

LAB8:    xsi_set_current_line(734, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(735, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(737, ng0);
    t1 = (t0 + 47336);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(752, ng0);
    t1 = (t0 + 15640U);
    t2 = *((char **)t1);
    t12 = *((unsigned char *)t2);
    t13 = (t12 == (unsigned char)3);
    if (t13 == 1)
        goto LAB90;

LAB91:    t1 = (t0 + 16280U);
    t3 = *((char **)t1);
    t14 = *((unsigned char *)t3);
    t15 = (t14 == (unsigned char)3);
    t11 = t15;

LAB92:    if (t11 == 1)
        goto LAB87;

LAB88:    t10 = (unsigned char)0;

LAB89:    if (t10 == 1)
        goto LAB84;

LAB85:    t9 = (unsigned char)0;

LAB86:    if (t9 == 1)
        goto LAB81;

LAB82:    t6 = (unsigned char)0;

LAB83:    if (t6 != 0)
        goto LAB78;

LAB80:    t1 = (t0 + 16440U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB93;

LAB94:    xsi_set_current_line(769, ng0);
    t1 = (t0 + 12600U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (t0 + 47400);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = t6;
    xsi_driver_first_trans_fast(t1);

LAB79:    xsi_set_current_line(781, ng0);
    t1 = (t0 + 8920U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB95;

LAB97:    xsi_set_current_line(784, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);

LAB96:    goto LAB2;

LAB9:    xsi_set_current_line(800, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(801, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(802, ng0);
    t1 = (t0 + 47336);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(803, ng0);
    t1 = (t0 + 14680U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB98;

LAB100:    xsi_set_current_line(813, ng0);
    t1 = (t0 + 16440U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB101;

LAB103:    t1 = (t0 + 16760U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB113;

LAB114:    xsi_set_current_line(835, ng0);
    t1 = (t0 + 17560U);
    t2 = *((char **)t1);
    t1 = (t0 + 3640U);
    t3 = *((char **)t1);
    t6 = 1;
    if (10U == 10U)
        goto LAB127;

LAB128:    t6 = 0;

LAB129:    if (t6 != 0)
        goto LAB124;

LAB126:
LAB125:
LAB102:
LAB99:    goto LAB2;

LAB10:    xsi_set_current_line(844, ng0);
    t1 = (t0 + 10520U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t9 = (t6 == (unsigned char)3);
    if (t9 != 0)
        goto LAB133;

LAB135:    xsi_set_current_line(847, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)7;
    xsi_driver_first_trans_fast(t1);

LAB134:    goto LAB2;

LAB11:    xsi_set_current_line(854, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(855, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(856, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(857, ng0);
    t1 = (t0 + 17560U);
    t2 = *((char **)t1);
    t1 = (t0 + 3480U);
    t3 = *((char **)t1);
    t6 = 1;
    if (10U == 10U)
        goto LAB139;

LAB140:    t6 = 0;

LAB141:    if (t6 != 0)
        goto LAB136;

LAB138:    xsi_set_current_line(860, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)8;
    xsi_driver_first_trans_fast(t1);

LAB137:    goto LAB2;

LAB12:    xsi_set_current_line(865, ng0);
    t1 = (t0 + 47656);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB13:    xsi_set_current_line(641, ng0);
    t1 = (t0 + 47656);
    t5 = (t1 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t16 = *((char **)t8);
    *((unsigned char *)t16) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);
    goto LAB14;

LAB16:    t1 = (t0 + 16120U);
    t4 = *((char **)t1);
    t14 = *((unsigned char *)t4);
    t15 = (t14 == (unsigned char)3);
    t6 = t15;
    goto LAB18;

LAB19:    t1 = (t0 + 15800U);
    t3 = *((char **)t1);
    t12 = *((unsigned char *)t3);
    t13 = (t12 == (unsigned char)2);
    t9 = t13;
    goto LAB21;

LAB22:    xsi_set_current_line(653, ng0);
    t1 = (t0 + 47656);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB23;

LAB25:    xsi_set_current_line(667, ng0);
    t1 = (t0 + 25216U);
    t3 = *((char **)t1);
    t10 = *((unsigned char *)t3);
    t11 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t10);
    t1 = (t0 + 47720);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t11;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB26;

LAB28:    xsi_set_current_line(671, ng0);
    t5 = (t0 + 47656);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    t16 = (t8 + 56U);
    t18 = *((char **)t16);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t5);
    goto LAB29;

LAB31:    t17 = 0;

LAB34:    if (t17 < 10U)
        goto LAB35;
    else
        goto LAB33;

LAB35:    t1 = (t2 + t17);
    t4 = (t3 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t4))
        goto LAB32;

LAB36:    t17 = (t17 + 1);
    goto LAB34;

LAB37:    xsi_set_current_line(681, ng0);
    t1 = (t0 + 47528);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(682, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB38;

LAB40:    xsi_set_current_line(689, ng0);
    t7 = (t0 + 47656);
    t8 = (t7 + 56U);
    t16 = *((char **)t8);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)4;
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(690, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(691, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB41;

LAB43:    t1 = (t0 + 17560U);
    t3 = *((char **)t1);
    t1 = (t0 + 3960U);
    t4 = *((char **)t1);
    t11 = 1;
    if (10U == 10U)
        goto LAB46;

LAB47:    t11 = 0;

LAB48:    t6 = t11;
    goto LAB45;

LAB46:    t17 = 0;

LAB49:    if (t17 < 10U)
        goto LAB50;
    else
        goto LAB48;

LAB50:    t1 = (t3 + t17);
    t5 = (t4 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t5))
        goto LAB47;

LAB51:    t17 = (t17 + 1);
    goto LAB49;

LAB52:    xsi_set_current_line(709, ng0);
    t1 = (t0 + 47464);
    t8 = (t1 + 56U);
    t16 = *((char **)t8);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(712, ng0);
    t1 = (t0 + 47400);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB53;

LAB55:    t1 = (t0 + 8440U);
    t7 = *((char **)t1);
    t24 = *((unsigned char *)t7);
    t25 = (t24 != (unsigned char)6);
    t6 = t25;
    goto LAB57;

LAB58:    t1 = (t0 + 8440U);
    t5 = *((char **)t1);
    t22 = *((unsigned char *)t5);
    t23 = (t22 != (unsigned char)2);
    t9 = t23;
    goto LAB60;

LAB61:    t1 = (t0 + 8440U);
    t4 = *((char **)t1);
    t20 = *((unsigned char *)t4);
    t21 = (t20 != (unsigned char)4);
    t10 = t21;
    goto LAB63;

LAB64:    t11 = (unsigned char)1;
    goto LAB66;

LAB67:    xsi_set_current_line(716, ng0);
    t1 = (t0 + 47400);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB53;

LAB69:    xsi_set_current_line(728, ng0);
    t5 = (t0 + 47656);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    t16 = (t8 + 56U);
    t18 = *((char **)t16);
    *((unsigned char *)t18) = (unsigned char)5;
    xsi_driver_first_trans_fast(t5);
    goto LAB70;

LAB72:    t17 = 0;

LAB75:    if (t17 < 10U)
        goto LAB76;
    else
        goto LAB74;

LAB76:    t1 = (t2 + t17);
    t4 = (t3 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t4))
        goto LAB73;

LAB77:    t17 = (t17 + 1);
    goto LAB75;

LAB78:    xsi_set_current_line(756, ng0);
    t1 = (t0 + 47464);
    t8 = (t1 + 56U);
    t16 = *((char **)t8);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(759, ng0);
    t1 = (t0 + 47400);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB79;

LAB81:    t1 = (t0 + 8440U);
    t7 = *((char **)t1);
    t24 = *((unsigned char *)t7);
    t25 = (t24 != (unsigned char)6);
    t6 = t25;
    goto LAB83;

LAB84:    t1 = (t0 + 8440U);
    t5 = *((char **)t1);
    t22 = *((unsigned char *)t5);
    t23 = (t22 != (unsigned char)2);
    t9 = t23;
    goto LAB86;

LAB87:    t1 = (t0 + 8440U);
    t4 = *((char **)t1);
    t20 = *((unsigned char *)t4);
    t21 = (t20 != (unsigned char)4);
    t10 = t21;
    goto LAB89;

LAB90:    t11 = (unsigned char)1;
    goto LAB92;

LAB93:    xsi_set_current_line(767, ng0);
    t1 = (t0 + 47400);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB79;

LAB95:    xsi_set_current_line(782, ng0);
    t1 = (t0 + 47656);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)6;
    xsi_driver_first_trans_fast(t1);
    goto LAB96;

LAB98:    xsi_set_current_line(806, ng0);
    t1 = (t0 + 47656);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB99;

LAB101:    xsi_set_current_line(814, ng0);
    t1 = (t0 + 17560U);
    t3 = *((char **)t1);
    t1 = (t0 + 2840U);
    t4 = *((char **)t1);
    t10 = 1;
    if (10U == 10U)
        goto LAB107;

LAB108:    t10 = 0;

LAB109:    if (t10 != 0)
        goto LAB104;

LAB106:
LAB105:    goto LAB102;

LAB104:    xsi_set_current_line(818, ng0);
    t7 = (t0 + 47656);
    t8 = (t7 + 56U);
    t16 = *((char **)t8);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(819, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(820, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB105;

LAB107:    t17 = 0;

LAB110:    if (t17 < 10U)
        goto LAB111;
    else
        goto LAB109;

LAB111:    t1 = (t3 + t17);
    t5 = (t4 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t5))
        goto LAB108;

LAB112:    t17 = (t17 + 1);
    goto LAB110;

LAB113:    xsi_set_current_line(823, ng0);
    t1 = (t0 + 17560U);
    t3 = *((char **)t1);
    t1 = (t0 + 3000U);
    t4 = *((char **)t1);
    t10 = 1;
    if (10U == 10U)
        goto LAB118;

LAB119:    t10 = 0;

LAB120:    if (t10 != 0)
        goto LAB115;

LAB117:
LAB116:    goto LAB102;

LAB115:    xsi_set_current_line(827, ng0);
    t7 = (t0 + 47656);
    t8 = (t7 + 56U);
    t16 = *((char **)t8);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)7;
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(828, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(829, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(830, ng0);
    t1 = (t0 + 47400);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(831, ng0);
    t1 = (t0 + 47464);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB116;

LAB118:    t17 = 0;

LAB121:    if (t17 < 10U)
        goto LAB122;
    else
        goto LAB120;

LAB122:    t1 = (t3 + t17);
    t5 = (t4 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t5))
        goto LAB119;

LAB123:    t17 = (t17 + 1);
    goto LAB121;

LAB124:    xsi_set_current_line(836, ng0);
    t5 = (t0 + 47656);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    t16 = (t8 + 56U);
    t18 = *((char **)t16);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(837, ng0);
    t1 = (t0 + 47592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(838, ng0);
    t1 = (t0 + 47528);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB125;

LAB127:    t17 = 0;

LAB130:    if (t17 < 10U)
        goto LAB131;
    else
        goto LAB129;

LAB131:    t1 = (t2 + t17);
    t4 = (t3 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t4))
        goto LAB128;

LAB132:    t17 = (t17 + 1);
    goto LAB130;

LAB133:    xsi_set_current_line(845, ng0);
    t1 = (t0 + 47656);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)8;
    xsi_driver_first_trans_fast(t1);
    goto LAB134;

LAB136:    xsi_set_current_line(858, ng0);
    t5 = (t0 + 47656);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    t16 = (t8 + 56U);
    t18 = *((char **)t16);
    *((unsigned char *)t18) = (unsigned char)0;
    xsi_driver_first_trans_fast(t5);
    goto LAB137;

LAB139:    t17 = 0;

LAB142:    if (t17 < 10U)
        goto LAB143;
    else
        goto LAB141;

LAB143:    t1 = (t2 + t17);
    t4 = (t3 + t17);
    if (*((unsigned char *)t1) != *((unsigned char *)t4))
        goto LAB140;

LAB144:    t17 = (t17 + 1);
    goto LAB142;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_19(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(877, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 44952);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(878, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(884, ng0);
    t2 = (t0 + 8760U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 47784);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(885, ng0);
    t2 = (t0 + 11800U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 47848);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(888, ng0);
    t2 = (t0 + 9400U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 4440U);
    t5 = *((char **)t2);
    t3 = *((unsigned char *)t5);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t1, t6);
    t2 = (t0 + 47912);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t7;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(889, ng0);
    t2 = (t0 + 16600U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 47976);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(879, ng0);
    t4 = (t0 + 47784);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)0;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(880, ng0);
    t2 = (t0 + 47848);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(881, ng0);
    t2 = (t0 + 47912);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(882, ng0);
    t2 = (t0 + 47976);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_20(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(919, ng0);

LAB3:    t1 = (t0 + 1880U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 48040);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 44968);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_21(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(920, ng0);

LAB3:    t1 = (t0 + 2360U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 48104);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 44984);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_22(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(924, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45000);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(926, ng0);
    t4 = (t0 + 10520U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 48168);
    t10 = (t4 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t9;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(928, ng0);
    t2 = (t0 + 8920U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 48232);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(930, ng0);
    t2 = (t0 + 11960U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 48296);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t1;
    xsi_driver_first_trans_fast(t2);
    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_23(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    xsi_set_current_line(943, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45016);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(944, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(948, ng0);
    t2 = (t0 + 4760U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 15160U);
    t5 = *((char **)t2);
    t3 = *((unsigned char *)t5);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t1, t6);
    t2 = (t0 + 14840U);
    t8 = *((char **)t2);
    t9 = *((unsigned char *)t8);
    t2 = (t0 + 19480U);
    t10 = *((char **)t2);
    t11 = *((unsigned char *)t10);
    t2 = (t0 + 19640U);
    t13 = *((char **)t2);
    t12 = *((unsigned char *)t13);
    t17 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t12);
    t18 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t11, t17);
    t19 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t18);
    t20 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t19);
    t2 = (t0 + 15160U);
    t14 = *((char **)t2);
    t21 = *((unsigned char *)t14);
    t22 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t21);
    t23 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t20, t22);
    t2 = (t0 + 5080U);
    t15 = *((char **)t2);
    t24 = *((unsigned char *)t15);
    t25 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t24);
    t26 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t23, t25);
    t2 = (t0 + 20920U);
    t16 = *((char **)t2);
    t27 = *((unsigned char *)t16);
    t28 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t27);
    t29 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t26, t28);
    t30 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t29);
    t2 = (t0 + 48360);
    t31 = (t2 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    *((unsigned char *)t34) = t30;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(952, ng0);
    t2 = (t0 + 14840U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 48424);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(945, ng0);
    t4 = (t0 + 48360);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(946, ng0);
    t2 = (t0 + 48424);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_24(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(963, ng0);

LAB3:    t1 = (t0 + 10840U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 10520U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t6);
    t1 = (t0 + 48488);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast(t1);

LAB2:    t12 = (t0 + 45032);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_25(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(964, ng0);

LAB3:    t1 = (t0 + 10840U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 10520U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t6);
    t1 = (t0 + 48552);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast(t1);

LAB2:    t12 = (t0 + 45048);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_26(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(965, ng0);

LAB3:    t1 = (t0 + 11000U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 11160U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t5);
    t1 = (t0 + 23000U);
    t7 = *((char **)t1);
    t8 = *((unsigned char *)t7);
    t9 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t6, t8);
    t1 = (t0 + 23160U);
    t10 = *((char **)t1);
    t11 = *((unsigned char *)t10);
    t12 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t9, t11);
    t1 = (t0 + 23480U);
    t13 = *((char **)t1);
    t14 = *((unsigned char *)t13);
    t15 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t12, t14);
    t1 = (t0 + 48616);
    t16 = (t1 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = t15;
    xsi_driver_first_trans_fast(t1);

LAB2:    t20 = (t0 + 45064);
    *((int *)t20) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_27(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(974, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45080);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(975, ng0);
    t4 = (t0 + 1720U);
    t9 = *((char **)t4);
    t10 = *((unsigned char *)t9);
    t4 = (t0 + 25216U);
    t11 = *((char **)t4);
    t12 = *((unsigned char *)t11);
    t13 = (t10 == t12);
    if (t13 == 1)
        goto LAB11;

LAB12:    t4 = (t0 + 8440U);
    t14 = *((char **)t4);
    t15 = *((unsigned char *)t14);
    t16 = (t15 == (unsigned char)1);
    t8 = t16;

LAB13:    if (t8 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 11000U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB14;

LAB15:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(976, ng0);
    t4 = (t0 + 48680);
    t17 = (t4 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    t8 = (unsigned char)1;
    goto LAB13;

LAB14:    xsi_set_current_line(978, ng0);
    t2 = (t0 + 8920U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    if (t7 != 0)
        goto LAB16;

LAB18:    xsi_set_current_line(981, ng0);
    t2 = (t0 + 48680);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB17:    goto LAB9;

LAB16:    xsi_set_current_line(979, ng0);
    t2 = (t0 + 48680);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t14 = (t11 + 56U);
    t17 = *((char **)t14);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB17;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_28(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(993, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45096);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(994, ng0);
    t4 = (t0 + 1720U);
    t9 = *((char **)t4);
    t10 = *((unsigned char *)t9);
    t4 = (t0 + 25216U);
    t11 = *((char **)t4);
    t12 = *((unsigned char *)t11);
    t13 = (t10 == t12);
    if (t13 == 1)
        goto LAB11;

LAB12:    t4 = (t0 + 15320U);
    t14 = *((char **)t4);
    t15 = *((unsigned char *)t14);
    t16 = (t15 == (unsigned char)3);
    t8 = t16;

LAB13:    if (t8 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 11160U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB14;

LAB15:    t2 = (t0 + 15000U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)2);
    if (t6 == 1)
        goto LAB21;

LAB22:    t1 = (unsigned char)0;

LAB23:    if (t1 != 0)
        goto LAB19;

LAB20:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(995, ng0);
    t4 = (t0 + 48744);
    t17 = (t4 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    t8 = (unsigned char)1;
    goto LAB13;

LAB14:    xsi_set_current_line(997, ng0);
    t2 = (t0 + 8920U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    if (t7 != 0)
        goto LAB16;

LAB18:    xsi_set_current_line(1000, ng0);
    t2 = (t0 + 48744);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB17:    goto LAB9;

LAB16:    xsi_set_current_line(998, ng0);
    t2 = (t0 + 48744);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t14 = (t11 + 56U);
    t17 = *((char **)t14);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB17;

LAB19:    xsi_set_current_line(1004, ng0);
    t2 = (t0 + 48744);
    t9 = (t2 + 56U);
    t11 = *((char **)t9);
    t14 = (t11 + 56U);
    t17 = *((char **)t14);
    *((unsigned char *)t17) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB21:    t2 = (t0 + 14840U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t8 = (t7 == (unsigned char)3);
    t1 = t8;
    goto LAB23;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_29(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1017, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45112);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1018, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1021, ng0);
    t2 = (t0 + 15480U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB13:    t2 = (t0 + 15320U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB14;

LAB15:
LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1019, ng0);
    t4 = (t0 + 48808);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1022, ng0);
    t2 = (t0 + 48808);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

LAB14:    xsi_set_current_line(1024, ng0);
    t2 = (t0 + 48808);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_30(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1038, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45128);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1039, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1042, ng0);
    t2 = (t0 + 15800U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 48872);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1040, ng0);
    t4 = (t0 + 48872);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_31(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1055, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45144);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1056, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1059, ng0);
    t2 = (t0 + 15000U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)2);
    if (t6 == 1)
        goto LAB14;

LAB15:    t1 = (unsigned char)0;

LAB16:    if (t1 != 0)
        goto LAB11;

LAB13:    t2 = (t0 + 15320U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB17;

LAB18:
LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1057, ng0);
    t4 = (t0 + 48936);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1061, ng0);
    t2 = (t0 + 48936);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

LAB14:    t2 = (t0 + 14840U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)3);
    t1 = t9;
    goto LAB16;

LAB17:    xsi_set_current_line(1063, ng0);
    t2 = (t0 + 48936);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_32(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;

LAB0:    xsi_set_current_line(1077, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45160);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1078, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1081, ng0);
    t2 = (t0 + 14680U);
    t4 = *((char **)t2);
    t6 = *((unsigned char *)t4);
    t7 = (t6 == (unsigned char)2);
    if (t7 == 1)
        goto LAB17;

LAB18:    t3 = (unsigned char)0;

LAB19:    if (t3 == 1)
        goto LAB14;

LAB15:    t1 = (unsigned char)0;

LAB16:    if (t1 != 0)
        goto LAB11;

LAB13:    t2 = (t0 + 15480U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB20;

LAB21:
LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1079, ng0);
    t4 = (t0 + 49000);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1084, ng0);
    t2 = (t0 + 49000);
    t10 = (t2 + 56U);
    t13 = *((char **)t10);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

LAB14:    t2 = (t0 + 14840U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)2);
    t1 = t17;
    goto LAB16;

LAB17:    t2 = (t0 + 15000U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)3);
    t3 = t11;
    goto LAB19;

LAB20:    xsi_set_current_line(1086, ng0);
    t2 = (t0 + 49000);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_33(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1100, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45176);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1101, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1104, ng0);
    t2 = (t0 + 15800U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB11;

LAB13:    t2 = (t0 + 14680U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB14;

LAB15:    xsi_set_current_line(1109, ng0);
    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49064);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1102, ng0);
    t4 = (t0 + 49064);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1105, ng0);
    t2 = (t0 + 14840U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 49064);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t6;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

LAB14:    xsi_set_current_line(1107, ng0);
    t2 = (t0 + 49064);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_34(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(1115, ng0);

LAB3:    t1 = (t0 + 5240U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 49128);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);

LAB2:    t8 = (t0 + 45192);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_35(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1126, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45208);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1127, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 16280U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 16280U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB15;

LAB16:    t1 = (unsigned char)0;

LAB17:    if (t1 != 0)
        goto LAB13;

LAB14:    xsi_set_current_line(1134, ng0);
    t2 = (t0 + 22520U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49192);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1128, ng0);
    t4 = (t0 + 49192);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1130, ng0);
    t2 = (t0 + 49192);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    xsi_set_current_line(1132, ng0);
    t2 = (t0 + 49192);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB15:    t2 = (t0 + 8920U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)3);
    t1 = t9;
    goto LAB17;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_36(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1147, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45224);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1148, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1155, ng0);
    t2 = (t0 + 9240U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 8920U);
    t5 = *((char **)t2);
    t3 = *((unsigned char *)t5);
    t6 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t1, t6);
    t2 = (t0 + 49256);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t7;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1156, ng0);
    t2 = (t0 + 9240U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t1);
    t2 = (t0 + 8920U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t6);
    t2 = (t0 + 49320);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t7;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1157, ng0);
    t2 = (t0 + 9880U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49384);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1158, ng0);
    t2 = (t0 + 10040U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49448);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1159, ng0);
    t2 = (t0 + 10200U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49512);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1149, ng0);
    t4 = (t0 + 49256);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(1150, ng0);
    t2 = (t0 + 49320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1151, ng0);
    t2 = (t0 + 49384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1152, ng0);
    t2 = (t0 + 49448);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1153, ng0);
    t2 = (t0 + 49512);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_37(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1172, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45240);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1173, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 10360U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1178, ng0);
    t2 = (t0 + 49576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1174, ng0);
    t4 = (t0 + 49576);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1176, ng0);
    t2 = (t0 + 49576);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB9;

LAB13:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)2);
    t1 = t9;
    goto LAB15;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_38(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1191, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45256);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1192, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)4);
    if (t3 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1197, ng0);
    t2 = (t0 + 49640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1193, ng0);
    t4 = (t0 + 49640);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1195, ng0);
    t2 = (t0 + 49640);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_39(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned int t18;
    unsigned char t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(1210, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45272);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1211, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)4);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)3);
    if (t11 == 1)
        goto LAB16;

LAB17:    t7 = (unsigned char)0;

LAB18:    t1 = t7;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1217, ng0);
    t2 = (t0 + 49704);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1212, ng0);
    t4 = (t0 + 49704);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1215, ng0);
    t22 = (t0 + 49704);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t22);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t2 = (t0 + 16920U);
    t8 = *((char **)t2);
    t2 = (t0 + 25336U);
    t10 = *((char **)t2);
    t17 = 1;
    if (4U == 4U)
        goto LAB22;

LAB23:    t17 = 0;

LAB24:    if (t17 == 1)
        goto LAB19;

LAB20:    t14 = (t0 + 16920U);
    t15 = *((char **)t14);
    t14 = (t0 + 24856U);
    t16 = *((char **)t14);
    t19 = 1;
    if (4U == 4U)
        goto LAB28;

LAB29:    t19 = 0;

LAB30:    t12 = t19;

LAB21:    t7 = t12;
    goto LAB18;

LAB19:    t12 = (unsigned char)1;
    goto LAB21;

LAB22:    t18 = 0;

LAB25:    if (t18 < 4U)
        goto LAB26;
    else
        goto LAB24;

LAB26:    t2 = (t8 + t18);
    t13 = (t10 + t18);
    if (*((unsigned char *)t2) != *((unsigned char *)t13))
        goto LAB23;

LAB27:    t18 = (t18 + 1);
    goto LAB25;

LAB28:    t20 = 0;

LAB31:    if (t20 < 4U)
        goto LAB32;
    else
        goto LAB30;

LAB32:    t14 = (t15 + t20);
    t21 = (t16 + t20);
    if (*((unsigned char *)t14) != *((unsigned char *)t21))
        goto LAB29;

LAB33:    t20 = (t20 + 1);
    goto LAB31;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_40(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    char *t18;
    char *t19;

LAB0:    xsi_set_current_line(1232, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45288);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1233, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 9880U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1234, ng0);
    t4 = (t0 + 49768);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1236, ng0);
    t2 = (t0 + 16920U);
    t5 = *((char **)t2);
    t2 = (t0 + 82367);
    t6 = 1;
    if (4U == 4U)
        goto LAB16;

LAB17:    t6 = 0;

LAB18:    if (t6 != 0)
        goto LAB13;

LAB15:    xsi_set_current_line(1239, ng0);
    t2 = (t0 + 49768);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB14:    goto LAB9;

LAB13:    xsi_set_current_line(1237, ng0);
    t14 = (t0 + 49768);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)3;
    xsi_driver_first_trans_fast(t14);
    goto LAB14;

LAB16:    t17 = 0;

LAB19:    if (t17 < 4U)
        goto LAB20;
    else
        goto LAB18;

LAB20:    t10 = (t5 + t17);
    t13 = (t2 + t17);
    if (*((unsigned char *)t10) != *((unsigned char *)t13))
        goto LAB17;

LAB21:    t17 = (t17 + 1);
    goto LAB19;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_41(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(1245, ng0);

LAB3:    t1 = (t0 + 19320U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 49832);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 45304);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_42(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1252, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45320);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1253, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1257, ng0);
    t2 = (t0 + 19320U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49896);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1258, ng0);
    t2 = (t0 + 19480U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 49960);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1254, ng0);
    t4 = (t0 + 49896);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(1255, ng0);
    t2 = (t0 + 49960);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_43(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1273, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45336);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1274, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 15480U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 14520U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)2);
    t1 = t9;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB16;

LAB17:    xsi_set_current_line(1282, ng0);
    t2 = (t0 + 18840U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 50024);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1275, ng0);
    t4 = (t0 + 50024);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1277, ng0);
    t2 = (t0 + 50024);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    xsi_set_current_line(1279, ng0);
    t2 = (t0 + 14520U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 50024);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t6;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_44(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(1294, ng0);
    t1 = (t0 + 18840U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 21880U);
    t4 = *((char **)t1);
    t5 = *((unsigned char *)t4);
    t6 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t3, t5);
    t1 = (t0 + 50088);
    t7 = (t1 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t6;
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 45352);
    *((int *)t1) = 1;

LAB1:    return;
}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_45(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(1305, ng0);

LAB3:    t1 = (t0 + 15800U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 50152);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 45368);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_46(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    xsi_set_current_line(1332, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45384);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1333, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 5240U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB31;

LAB32:    xsi_set_current_line(1347, ng0);
    t2 = (t0 + 50216);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1334, ng0);
    t4 = (t0 + 50216);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1336, ng0);
    t2 = (t0 + 14680U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)3);
    if (t11 == 1)
        goto LAB19;

LAB20:    t2 = (t0 + 15960U);
    t8 = *((char **)t2);
    t17 = *((unsigned char *)t8);
    t18 = (t17 == (unsigned char)3);
    if (t18 == 1)
        goto LAB22;

LAB23:    t12 = (unsigned char)0;

LAB24:    t7 = t12;

LAB21:    if (t7 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 15480U);
    t13 = *((char **)t2);
    t23 = *((unsigned char *)t13);
    t24 = (t23 == (unsigned char)3);
    if (t24 == 1)
        goto LAB28;

LAB29:    t22 = (unsigned char)0;

LAB30:    if (t22 == 1)
        goto LAB25;

LAB26:    t21 = (unsigned char)0;

LAB27:    t6 = t21;

LAB18:    if (t6 != 0)
        goto LAB13;

LAB15:    xsi_set_current_line(1341, ng0);
    t2 = (t0 + 50216);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB14:    goto LAB9;

LAB13:    xsi_set_current_line(1339, ng0);
    t2 = (t0 + 50216);
    t16 = (t2 + 56U);
    t29 = *((char **)t16);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    *((unsigned char *)t31) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB14;

LAB16:    t6 = (unsigned char)1;
    goto LAB18;

LAB19:    t7 = (unsigned char)1;
    goto LAB21;

LAB22:    t2 = (t0 + 16120U);
    t10 = *((char **)t2);
    t19 = *((unsigned char *)t10);
    t20 = (t19 == (unsigned char)3);
    t12 = t20;
    goto LAB24;

LAB25:    t2 = (t0 + 15640U);
    t15 = *((char **)t2);
    t27 = *((unsigned char *)t15);
    t28 = (t27 == (unsigned char)2);
    t21 = t28;
    goto LAB27;

LAB28:    t2 = (t0 + 19960U);
    t14 = *((char **)t2);
    t25 = *((unsigned char *)t14);
    t26 = (t25 == (unsigned char)2);
    t22 = t26;
    goto LAB30;

LAB31:    xsi_set_current_line(1345, ng0);
    t2 = (t0 + 50216);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_47(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(1359, ng0);
    t1 = (t0 + 19800U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 50280);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 45400);
    *((int *)t1) = 1;

LAB1:    return;
}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_48(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;

LAB0:    xsi_set_current_line(1371, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45416);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1372, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 16280U);
    t4 = *((char **)t2);
    t6 = *((unsigned char *)t4);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 15640U);
    t8 = *((char **)t2);
    t17 = *((unsigned char *)t8);
    t18 = (t17 == (unsigned char)3);
    if (t18 == 1)
        goto LAB19;

LAB20:    t12 = (unsigned char)0;

LAB21:    t1 = t12;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 15320U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB22;

LAB23:    xsi_set_current_line(1380, ng0);
    t2 = (t0 + 19960U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 50344);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1373, ng0);
    t4 = (t0 + 50344);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1376, ng0);
    t2 = (t0 + 50344);
    t13 = (t2 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t2 = (t0 + 15320U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)2);
    t3 = t11;
    goto LAB18;

LAB19:    t2 = (t0 + 15320U);
    t10 = *((char **)t2);
    t19 = *((unsigned char *)t10);
    t20 = (t19 == (unsigned char)2);
    t12 = t20;
    goto LAB21;

LAB22:    xsi_set_current_line(1378, ng0);
    t2 = (t0 + 50344);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_49(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;

LAB0:    xsi_set_current_line(1396, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45432);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1397, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1402, ng0);
    t2 = (t0 + 19000U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 50408);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1398, ng0);
    t4 = (t0 + 50408);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1400, ng0);
    t2 = (t0 + 13880U);
    t5 = *((char **)t2);
    t17 = (0 - 7);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t2 = (t5 + t20);
    t6 = *((unsigned char *)t2);
    t8 = (t0 + 50408);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t6;
    xsi_driver_first_trans_fast(t8);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_50(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(1407, ng0);

LAB3:    t1 = (t0 + 19000U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 50472);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 45448);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_51(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;

LAB0:    xsi_set_current_line(1418, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45464);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1419, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 9880U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1420, ng0);
    t4 = (t0 + 50536);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1422, ng0);
    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)2);
    if (t11 == 1)
        goto LAB19;

LAB20:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)4);
    t7 = t17;

LAB21:    if (t7 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 8440U);
    t10 = *((char **)t2);
    t18 = *((unsigned char *)t10);
    t19 = (t18 == (unsigned char)6);
    t6 = t19;

LAB18:    if (t6 != 0)
        goto LAB13;

LAB15:
LAB14:    goto LAB9;

LAB13:    xsi_set_current_line(1423, ng0);
    t2 = (t0 + 12280U);
    t13 = *((char **)t2);
    t20 = *((unsigned char *)t13);
    t2 = (t0 + 50536);
    t14 = (t2 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t21 = *((char **)t16);
    *((unsigned char *)t21) = t20;
    xsi_driver_first_trans_fast(t2);
    goto LAB14;

LAB16:    t6 = (unsigned char)1;
    goto LAB18;

LAB19:    t7 = (unsigned char)1;
    goto LAB21;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_52(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;

LAB0:    xsi_set_current_line(1436, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45480);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1437, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 9880U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 10200U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB22;

LAB23:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1438, ng0);
    t4 = (t0 + 50600);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1440, ng0);
    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)2);
    if (t11 == 1)
        goto LAB19;

LAB20:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)4);
    t7 = t17;

LAB21:    if (t7 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 8440U);
    t10 = *((char **)t2);
    t18 = *((unsigned char *)t10);
    t19 = (t18 == (unsigned char)6);
    t6 = t19;

LAB18:    if (t6 != 0)
        goto LAB13;

LAB15:
LAB14:    goto LAB9;

LAB13:    xsi_set_current_line(1441, ng0);
    t2 = (t0 + 12280U);
    t13 = *((char **)t2);
    t20 = *((unsigned char *)t13);
    t2 = (t0 + 50600);
    t14 = (t2 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t21 = *((char **)t16);
    *((unsigned char *)t21) = t20;
    xsi_driver_first_trans_fast(t2);
    goto LAB14;

LAB16:    t6 = (unsigned char)1;
    goto LAB18;

LAB19:    t7 = (unsigned char)1;
    goto LAB21;

LAB22:    xsi_set_current_line(1444, ng0);
    t2 = (t0 + 50600);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_53(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(1449, ng0);

LAB3:    t1 = (t0 + 21080U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 50664);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 45496);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_54(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;

LAB0:    xsi_set_current_line(1457, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45512);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1458, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t7 = *((unsigned char *)t4);
    t9 = (t7 == (unsigned char)4);
    if (t9 == 1)
        goto LAB19;

LAB20:    t6 = (unsigned char)0;

LAB21:    if (t6 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1466, ng0);
    t2 = (t0 + 18680U);
    t4 = *((char **)t2);
    t2 = (t0 + 50728);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t4, 8U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1467, ng0);
    t2 = (t0 + 50792);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1459, ng0);
    t4 = xsi_get_transient_memory(8U);
    memset(t4, 0, 8U);
    t13 = t4;
    memset(t13, (unsigned char)2, 8U);
    t14 = (t0 + 50728);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t4, 8U);
    xsi_driver_first_trans_fast(t14);
    xsi_set_current_line(1460, ng0);
    t2 = (t0 + 50792);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB11:    xsi_set_current_line(1463, ng0);
    t2 = (t0 + 13080U);
    t13 = *((char **)t2);
    t2 = (t0 + 50728);
    t14 = (t2 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t13, 8U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1464, ng0);
    t2 = (t0 + 50792);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t2 = (t0 + 22040U);
    t10 = *((char **)t2);
    t21 = *((unsigned char *)t10);
    t22 = (t21 == (unsigned char)2);
    t1 = t22;
    goto LAB15;

LAB16:    t2 = (t0 + 9880U);
    t8 = *((char **)t2);
    t19 = *((unsigned char *)t8);
    t20 = (t19 == (unsigned char)3);
    t3 = t20;
    goto LAB18;

LAB19:    t2 = (t0 + 4440U);
    t5 = *((char **)t2);
    t11 = *((unsigned char *)t5);
    t12 = (t11 == (unsigned char)2);
    t6 = t12;
    goto LAB21;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_55(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(1479, ng0);
    t1 = (t0 + 22200U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 50856);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 45528);
    *((int *)t1) = 1;

LAB1:    return;
}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_56(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(1482, ng0);

LAB3:    t1 = (t0 + 18680U);
    t2 = *((char **)t1);
    t1 = (t0 + 50920);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 45544);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_57(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned char t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;

LAB0:    xsi_set_current_line(1493, ng0);
    t2 = (t0 + 13880U);
    t3 = *((char **)t2);
    t4 = (7 - 7);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t2 = (t3 + t6);
    t7 = (t0 + 5880U);
    t8 = *((char **)t7);
    t9 = (7 - 7);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t7 = (t8 + t11);
    t12 = 1;
    if (7U == 7U)
        goto LAB8;

LAB9:    t12 = 0;

LAB10:    if (t12 == 1)
        goto LAB5;

LAB6:    t16 = (t0 + 19160U);
    t17 = *((char **)t16);
    t18 = *((unsigned char *)t17);
    t19 = (t18 == (unsigned char)3);
    t1 = t19;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB14:    t24 = (t0 + 50984);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    *((unsigned char *)t28) = (unsigned char)2;
    xsi_driver_first_trans_fast(t24);

LAB2:    t29 = (t0 + 45560);
    *((int *)t29) = 1;

LAB1:    return;
LAB3:    t16 = (t0 + 50984);
    t20 = (t16 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t16);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t13 = 0;

LAB11:    if (t13 < 7U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t14 = (t2 + t13);
    t15 = (t7 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB9;

LAB13:    t13 = (t13 + 1);
    goto LAB11;

LAB15:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_58(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    xsi_set_current_line(1498, ng0);

LAB3:    t1 = (t0 + 51048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_59(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;

LAB0:    xsi_set_current_line(1648, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45576);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1649, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 15480U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 15320U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)3);
    t1 = t9;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 13880U);
    t4 = *((char **)t2);
    t17 = (7 - 7);
    t18 = (t17 * 1U);
    t19 = (0 + t18);
    t2 = (t4 + t19);
    t5 = (t0 + 82371);
    t6 = 1;
    if (8U == 8U)
        goto LAB24;

LAB25:    t6 = 0;

LAB26:    if (t6 == 1)
        goto LAB21;

LAB22:    t3 = (unsigned char)0;

LAB23:    if (t3 == 1)
        goto LAB18;

LAB19:    t1 = (unsigned char)0;

LAB20:    if (t1 != 0)
        goto LAB16;

LAB17:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1650, ng0);
    t4 = (t0 + 51112);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1652, ng0);
    t2 = (t0 + 51112);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    xsi_set_current_line(1655, ng0);
    t14 = (t0 + 51112);
    t21 = (t14 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)3;
    xsi_driver_first_trans_fast(t14);
    goto LAB9;

LAB18:    t14 = (t0 + 8440U);
    t16 = *((char **)t14);
    t11 = *((unsigned char *)t16);
    t12 = (t11 == (unsigned char)2);
    t1 = t12;
    goto LAB20;

LAB21:    t14 = (t0 + 4280U);
    t15 = *((char **)t14);
    t7 = *((unsigned char *)t15);
    t9 = (t7 == (unsigned char)3);
    t3 = t9;
    goto LAB23;

LAB24:    t20 = 0;

LAB27:    if (t20 < 8U)
        goto LAB28;
    else
        goto LAB26;

LAB28:    t10 = (t2 + t20);
    t13 = (t5 + t20);
    if (*((unsigned char *)t10) != *((unsigned char *)t13))
        goto LAB25;

LAB29:    t20 = (t20 + 1);
    goto LAB27;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_60(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(1660, ng0);

LAB3:    t1 = (t0 + 19160U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 51176);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 45592);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_61(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1669, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45608);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1670, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 9720U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB11;

LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1671, ng0);
    t4 = (t0 + 51240);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1673, ng0);
    t2 = (t0 + 10520U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 51240);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t6;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_62(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned char t21;
    char *t22;
    unsigned int t23;
    int t24;
    unsigned int t25;
    unsigned int t26;
    static char *nl0[] = {&&LAB23, &&LAB24, &&LAB25, &&LAB26, &&LAB28, &&LAB27, &&LAB29};

LAB0:    xsi_set_current_line(1690, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45624);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1691, ng0);
    t4 = (t0 + 1720U);
    t9 = *((char **)t4);
    t10 = *((unsigned char *)t9);
    t4 = (t0 + 25216U);
    t11 = *((char **)t4);
    t12 = *((unsigned char *)t11);
    t13 = (t10 == t12);
    if (t13 == 1)
        goto LAB11;

LAB12:    t4 = (t0 + 15480U);
    t14 = *((char **)t4);
    t15 = *((unsigned char *)t14);
    t16 = (t15 == (unsigned char)3);
    t8 = t16;

LAB13:    if (t8 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 10200U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 4440U);
    t5 = *((char **)t2);
    t8 = *((unsigned char *)t5);
    t10 = (t8 == (unsigned char)2);
    if (t10 == 1)
        goto LAB19;

LAB20:    t7 = (unsigned char)0;

LAB21:    t1 = t7;

LAB18:    if (t1 != 0)
        goto LAB14;

LAB15:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1692, ng0);
    t4 = (t0 + 51304);
    t17 = (t4 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)0;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(1693, ng0);
    t2 = (t0 + 51368);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB11:    t8 = (unsigned char)1;
    goto LAB13;

LAB14:    xsi_set_current_line(1697, ng0);
    t2 = (t0 + 8440U);
    t11 = *((char **)t2);
    t15 = *((unsigned char *)t11);
    t2 = (char *)((nl0) + t15);
    goto **((char **)t2);

LAB16:    t1 = (unsigned char)1;
    goto LAB18;

LAB19:    t2 = (t0 + 22360U);
    t9 = *((char **)t2);
    t12 = *((unsigned char *)t9);
    t13 = (t12 == (unsigned char)3);
    t7 = t13;
    goto LAB21;

LAB22:    goto LAB9;

LAB23:    xsi_set_current_line(1701, ng0);
    t14 = (t0 + 15320U);
    t17 = *((char **)t14);
    t16 = *((unsigned char *)t17);
    t21 = (t16 == (unsigned char)3);
    if (t21 != 0)
        goto LAB31;

LAB33:
LAB32:    goto LAB22;

LAB24:    xsi_set_current_line(1707, ng0);
    t2 = (t0 + 16920U);
    t4 = *((char **)t2);
    t2 = (t0 + 24856U);
    t5 = *((char **)t2);
    t1 = 1;
    if (4U == 4U)
        goto LAB37;

LAB38:    t1 = 0;

LAB39:    if (t1 != 0)
        goto LAB34;

LAB36:
LAB35:    goto LAB22;

LAB25:    xsi_set_current_line(1713, ng0);
    t2 = (t0 + 14680U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB43;

LAB45:    t2 = (t0 + 12280U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB46;

LAB47:    xsi_set_current_line(1746, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(1747, ng0);
    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB60;

LAB62:
LAB61:
LAB44:    goto LAB22;

LAB26:    xsi_set_current_line(1757, ng0);
    t2 = (t0 + 15320U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB63;

LAB65:    t2 = (t0 + 16920U);
    t4 = *((char **)t2);
    t2 = (t0 + 24856U);
    t5 = *((char **)t2);
    t1 = 1;
    if (4U == 4U)
        goto LAB68;

LAB69:    t1 = 0;

LAB70:    if (t1 != 0)
        goto LAB66;

LAB67:
LAB64:    goto LAB22;

LAB27:    xsi_set_current_line(1772, ng0);
    t2 = (t0 + 15320U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB80;

LAB82:    t2 = (t0 + 16920U);
    t4 = *((char **)t2);
    t2 = (t0 + 24856U);
    t5 = *((char **)t2);
    t1 = 1;
    if (4U == 4U)
        goto LAB85;

LAB86:    t1 = 0;

LAB87:    if (t1 != 0)
        goto LAB83;

LAB84:
LAB81:    goto LAB22;

LAB28:    xsi_set_current_line(1785, ng0);
    t2 = (t0 + 4440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB91;

LAB93:    xsi_set_current_line(1788, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);

LAB92:    goto LAB22;

LAB29:    xsi_set_current_line(1793, ng0);
    t2 = (t0 + 14680U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB94;

LAB96:    t2 = (t0 + 12280U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB97;

LAB98:    xsi_set_current_line(1810, ng0);
    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB105;

LAB107:
LAB106:    xsi_set_current_line(1813, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);

LAB95:    goto LAB22;

LAB30:    xsi_set_current_line(1818, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB22;

LAB31:    xsi_set_current_line(1702, ng0);
    t14 = (t0 + 51304);
    t18 = (t14 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t22 = *((char **)t20);
    *((unsigned char *)t22) = (unsigned char)1;
    xsi_driver_first_trans_fast(t14);
    goto LAB32;

LAB34:    xsi_set_current_line(1708, ng0);
    t11 = (t0 + 51304);
    t14 = (t11 + 56U);
    t17 = *((char **)t14);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)2;
    xsi_driver_first_trans_fast(t11);
    goto LAB35;

LAB37:    t23 = 0;

LAB40:    if (t23 < 4U)
        goto LAB41;
    else
        goto LAB39;

LAB41:    t2 = (t4 + t23);
    t9 = (t5 + t23);
    if (*((unsigned char *)t2) != *((unsigned char *)t9))
        goto LAB38;

LAB42:    t23 = (t23 + 1);
    goto LAB40;

LAB43:    xsi_set_current_line(1714, ng0);
    t2 = (t0 + 51304);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB44;

LAB46:    xsi_set_current_line(1717, ng0);
    t2 = (t0 + 12920U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    if (t7 != 0)
        goto LAB48;

LAB50:    xsi_set_current_line(1727, ng0);
    t2 = (t0 + 14520U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB54;

LAB56:    xsi_set_current_line(1740, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);

LAB55:
LAB49:    goto LAB44;

LAB48:    xsi_set_current_line(1719, ng0);
    t2 = (t0 + 5560U);
    t9 = *((char **)t2);
    t8 = *((unsigned char *)t9);
    t10 = (t8 == (unsigned char)2);
    if (t10 != 0)
        goto LAB51;

LAB53:    xsi_set_current_line(1724, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)5;
    xsi_driver_first_trans_fast(t2);

LAB52:    goto LAB49;

LAB51:    xsi_set_current_line(1721, ng0);
    t2 = (t0 + 51304);
    t11 = (t2 + 56U);
    t14 = *((char **)t11);
    t17 = (t14 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB52;

LAB54:    xsi_set_current_line(1731, ng0);
    t2 = (t0 + 13880U);
    t5 = *((char **)t2);
    t24 = (0 - 7);
    t23 = (t24 * -1);
    t25 = (1U * t23);
    t26 = (0 + t25);
    t2 = (t5 + t26);
    t6 = *((unsigned char *)t2);
    t7 = (t6 == (unsigned char)2);
    if (t7 != 0)
        goto LAB57;

LAB59:    xsi_set_current_line(1736, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)5;
    xsi_driver_first_trans_fast(t2);

LAB58:    goto LAB55;

LAB57:    xsi_set_current_line(1733, ng0);
    t9 = (t0 + 51304);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    t17 = (t14 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t9);
    goto LAB58;

LAB60:    xsi_set_current_line(1748, ng0);
    t2 = (t0 + 51368);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB61;

LAB63:    xsi_set_current_line(1758, ng0);
    t2 = (t0 + 51304);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB64;

LAB66:    xsi_set_current_line(1760, ng0);
    t11 = (t0 + 12920U);
    t14 = *((char **)t11);
    t6 = *((unsigned char *)t14);
    t7 = (t6 == (unsigned char)2);
    if (t7 == 1)
        goto LAB77;

LAB78:    t3 = (unsigned char)0;

LAB79:    if (t3 != 0)
        goto LAB74;

LAB76:    xsi_set_current_line(1764, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);

LAB75:    goto LAB64;

LAB68:    t23 = 0;

LAB71:    if (t23 < 4U)
        goto LAB72;
    else
        goto LAB70;

LAB72:    t2 = (t4 + t23);
    t9 = (t5 + t23);
    if (*((unsigned char *)t2) != *((unsigned char *)t9))
        goto LAB69;

LAB73:    t23 = (t23 + 1);
    goto LAB71;

LAB74:    xsi_set_current_line(1761, ng0);
    t11 = (t0 + 51304);
    t18 = (t11 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t22 = *((char **)t20);
    *((unsigned char *)t22) = (unsigned char)0;
    xsi_driver_first_trans_fast(t11);
    goto LAB75;

LAB77:    t11 = (t0 + 14520U);
    t17 = *((char **)t11);
    t8 = *((unsigned char *)t17);
    t10 = (t8 == (unsigned char)2);
    t3 = t10;
    goto LAB79;

LAB80:    xsi_set_current_line(1773, ng0);
    t2 = (t0 + 51304);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB81;

LAB83:    xsi_set_current_line(1778, ng0);
    t11 = (t0 + 51304);
    t14 = (t11 + 56U);
    t17 = *((char **)t14);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)6;
    xsi_driver_first_trans_fast(t11);
    goto LAB81;

LAB85:    t23 = 0;

LAB88:    if (t23 < 4U)
        goto LAB89;
    else
        goto LAB87;

LAB89:    t2 = (t4 + t23);
    t9 = (t5 + t23);
    if (*((unsigned char *)t2) != *((unsigned char *)t9))
        goto LAB86;

LAB90:    t23 = (t23 + 1);
    goto LAB88;

LAB91:    xsi_set_current_line(1786, ng0);
    t2 = (t0 + 51304);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB92;

LAB94:    xsi_set_current_line(1794, ng0);
    t2 = (t0 + 51304);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB95;

LAB97:    xsi_set_current_line(1796, ng0);
    t2 = (t0 + 12920U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t8 = (t7 == (unsigned char)2);
    if (t8 == 1)
        goto LAB102;

LAB103:    t6 = (unsigned char)0;

LAB104:    if (t6 != 0)
        goto LAB99;

LAB101:    xsi_set_current_line(1799, ng0);
    t2 = (t0 + 51304);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t9 = (t5 + 56U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = (unsigned char)5;
    xsi_driver_first_trans_fast(t2);

LAB100:    goto LAB95;

LAB99:    xsi_set_current_line(1797, ng0);
    t2 = (t0 + 51304);
    t11 = (t2 + 56U);
    t14 = *((char **)t11);
    t17 = (t14 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB100;

LAB102:    t2 = (t0 + 14520U);
    t9 = *((char **)t2);
    t10 = *((unsigned char *)t9);
    t12 = (t10 == (unsigned char)2);
    t6 = t12;
    goto LAB104;

LAB105:    xsi_set_current_line(1811, ng0);
    t2 = (t0 + 51368);
    t5 = (t2 + 56U);
    t9 = *((char **)t5);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB106;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_63(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;

LAB0:    xsi_set_current_line(1834, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45640);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1835, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)1);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)5);
    if (t11 == 1)
        goto LAB16;

LAB17:    t7 = (unsigned char)0;

LAB18:    t1 = t7;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 20280U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB21;

LAB22:    t1 = (unsigned char)0;

LAB23:    if (t1 != 0)
        goto LAB19;

LAB20:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)4);
    if (t3 != 0)
        goto LAB24;

LAB25:    xsi_set_current_line(1850, ng0);
    t2 = (t0 + 51432);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1836, ng0);
    t4 = (t0 + 51432);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1841, ng0);
    t2 = (t0 + 13240U);
    t10 = *((char **)t2);
    t18 = *((unsigned char *)t10);
    t2 = (t0 + 51432);
    t13 = (t2 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t18;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t2 = (t0 + 20280U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)2);
    t7 = t17;
    goto LAB18;

LAB19:    xsi_set_current_line(1846, ng0);
    t2 = (t0 + 51432);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB21:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)5);
    t1 = t9;
    goto LAB23;

LAB24:    xsi_set_current_line(1848, ng0);
    t2 = (t0 + 4120U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 51432);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t6;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_64(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;

LAB0:    xsi_set_current_line(1893, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45656);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1894, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 14520U);
    t4 = *((char **)t2);
    t6 = *((unsigned char *)t4);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB16;

LAB17:    t3 = (unsigned char)0;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)4);
    t1 = t17;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)5);
    if (t3 != 0)
        goto LAB19;

LAB20:    xsi_set_current_line(1902, ng0);
    t2 = (t0 + 51496);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1895, ng0);
    t4 = (t0 + 51496);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1898, ng0);
    t2 = (t0 + 4120U);
    t10 = *((char **)t2);
    t18 = *((unsigned char *)t10);
    t2 = (t0 + 51496);
    t13 = (t2 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t18;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)2);
    t3 = t11;
    goto LAB18;

LAB19:    xsi_set_current_line(1900, ng0);
    t2 = (t0 + 13240U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 51496);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t6;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_65(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    unsigned char t29;
    unsigned char t30;
    unsigned char t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    unsigned char t35;
    unsigned char t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;

LAB0:    xsi_set_current_line(1926, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45672);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1927, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t9 = *((unsigned char *)t4);
    t11 = (t9 == (unsigned char)3);
    if (t11 == 1)
        goto LAB22;

LAB23:    t7 = (unsigned char)0;

LAB24:    if (t7 == 1)
        goto LAB19;

LAB20:    t6 = (unsigned char)0;

LAB21:    if (t6 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 8440U);
    t10 = *((char **)t2);
    t22 = *((unsigned char *)t10);
    t23 = (t22 == (unsigned char)3);
    if (t23 == 1)
        goto LAB28;

LAB29:    t21 = (unsigned char)0;

LAB30:    if (t21 == 1)
        goto LAB25;

LAB26:    t20 = (unsigned char)0;

LAB27:    t3 = t20;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8440U);
    t15 = *((char **)t2);
    t30 = *((unsigned char *)t15);
    t31 = (t30 == (unsigned char)5);
    if (t31 == 1)
        goto LAB34;

LAB35:    t29 = (unsigned char)0;

LAB36:    if (t29 == 1)
        goto LAB31;

LAB32:    t28 = (unsigned char)0;

LAB33:    t1 = t28;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1941, ng0);
    t2 = (t0 + 51560);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1928, ng0);
    t4 = (t0 + 51560);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1939, ng0);
    t2 = (t0 + 51560);
    t37 = (t2 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t3 = (unsigned char)1;
    goto LAB18;

LAB19:    t2 = (t0 + 9720U);
    t8 = *((char **)t2);
    t18 = *((unsigned char *)t8);
    t19 = (t18 == (unsigned char)3);
    t6 = t19;
    goto LAB21;

LAB22:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t12 = *((unsigned char *)t5);
    t17 = (t12 == (unsigned char)1);
    t7 = t17;
    goto LAB24;

LAB25:    t2 = (t0 + 15320U);
    t14 = *((char **)t2);
    t26 = *((unsigned char *)t14);
    t27 = (t26 == (unsigned char)2);
    t20 = t27;
    goto LAB27;

LAB28:    t2 = (t0 + 9720U);
    t13 = *((char **)t2);
    t24 = *((unsigned char *)t13);
    t25 = (t24 == (unsigned char)3);
    t21 = t25;
    goto LAB30;

LAB31:    t2 = (t0 + 15320U);
    t34 = *((char **)t2);
    t35 = *((unsigned char *)t34);
    t36 = (t35 == (unsigned char)2);
    t28 = t36;
    goto LAB33;

LAB34:    t2 = (t0 + 10200U);
    t16 = *((char **)t2);
    t32 = *((unsigned char *)t16);
    t33 = (t32 == (unsigned char)3);
    t29 = t33;
    goto LAB36;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_66(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    unsigned char t32;
    unsigned char t33;
    unsigned char t34;
    unsigned char t35;
    unsigned char t36;
    unsigned char t37;
    char *t38;
    unsigned char t39;
    unsigned char t40;
    char *t41;
    unsigned char t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    unsigned char t49;
    unsigned char t50;
    char *t51;
    unsigned char t52;
    unsigned char t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;

LAB0:    xsi_set_current_line(1951, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45688);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1952, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 12920U);
    t4 = *((char **)t2);
    t12 = *((unsigned char *)t4);
    t17 = (t12 == (unsigned char)3);
    if (t17 == 1)
        goto LAB28;

LAB29:    t11 = (unsigned char)0;

LAB30:    if (t11 == 1)
        goto LAB25;

LAB26:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t20 = *((unsigned char *)t8);
    t21 = (t20 == (unsigned char)6);
    t9 = t21;

LAB27:    if (t9 == 1)
        goto LAB22;

LAB23:    t2 = (t0 + 8440U);
    t10 = *((char **)t2);
    t24 = *((unsigned char *)t10);
    t25 = (t24 == (unsigned char)2);
    if (t25 == 1)
        goto LAB34;

LAB35:    t23 = (unsigned char)0;

LAB36:    if (t23 == 1)
        goto LAB31;

LAB32:    t22 = (unsigned char)0;

LAB33:    t7 = t22;

LAB24:    if (t7 == 1)
        goto LAB19;

LAB20:    t14 = (t0 + 8440U);
    t16 = *((char **)t14);
    t36 = *((unsigned char *)t16);
    t37 = (t36 == (unsigned char)2);
    if (t37 == 1)
        goto LAB40;

LAB41:    t35 = (unsigned char)0;

LAB42:    if (t35 == 1)
        goto LAB37;

LAB38:    t34 = (unsigned char)0;

LAB39:    t6 = t34;

LAB21:    if (t6 == 1)
        goto LAB16;

LAB17:    t14 = (t0 + 8440U);
    t45 = *((char **)t14);
    t46 = *((unsigned char *)t45);
    t47 = (t46 == (unsigned char)3);
    if (t47 == 1)
        goto LAB43;

LAB44:    t44 = (unsigned char)0;

LAB45:    t3 = t44;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t14 = (t0 + 20280U);
    t51 = *((char **)t14);
    t52 = *((unsigned char *)t51);
    t53 = (t52 == (unsigned char)3);
    t1 = t53;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(1967, ng0);
    t2 = (t0 + 51624);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1953, ng0);
    t4 = (t0 + 51624);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(1965, ng0);
    t14 = (t0 + 51624);
    t54 = (t14 + 56U);
    t55 = *((char **)t54);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    *((unsigned char *)t57) = (unsigned char)3;
    xsi_driver_first_trans_fast(t14);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t3 = (unsigned char)1;
    goto LAB18;

LAB19:    t6 = (unsigned char)1;
    goto LAB21;

LAB22:    t7 = (unsigned char)1;
    goto LAB24;

LAB25:    t9 = (unsigned char)1;
    goto LAB27;

LAB28:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t18 = *((unsigned char *)t5);
    t19 = (t18 == (unsigned char)0);
    t11 = t19;
    goto LAB30;

LAB31:    t14 = (t0 + 12920U);
    t15 = *((char **)t14);
    t32 = *((unsigned char *)t15);
    t33 = (t32 == (unsigned char)2);
    t22 = t33;
    goto LAB33;

LAB34:    t2 = (t0 + 13880U);
    t13 = *((char **)t2);
    t26 = (0 - 7);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t2 = (t13 + t29);
    t30 = *((unsigned char *)t2);
    t31 = (t30 == (unsigned char)3);
    t23 = t31;
    goto LAB36;

LAB37:    t14 = (t0 + 12920U);
    t41 = *((char **)t14);
    t42 = *((unsigned char *)t41);
    t43 = (t42 == (unsigned char)3);
    t34 = t43;
    goto LAB39;

LAB40:    t14 = (t0 + 5560U);
    t38 = *((char **)t14);
    t39 = *((unsigned char *)t38);
    t40 = (t39 == (unsigned char)3);
    t35 = t40;
    goto LAB42;

LAB43:    t14 = (t0 + 15320U);
    t48 = *((char **)t14);
    t49 = *((unsigned char *)t48);
    t50 = (t49 == (unsigned char)3);
    t44 = t50;
    goto LAB45;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_67(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(1979, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45704);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1980, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(1983, ng0);
    t2 = (t0 + 13560U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t2 = (t0 + 51688);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t13 = *((char **)t10);
    *((unsigned char *)t13) = t1;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1981, ng0);
    t4 = (t0 + 51688);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_68(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;

LAB0:    xsi_set_current_line(1997, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45720);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(1998, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)5);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8440U);
    t5 = *((char **)t2);
    t9 = *((unsigned char *)t5);
    t11 = (t9 == (unsigned char)1);
    if (t11 == 1)
        goto LAB16;

LAB17:    t7 = (unsigned char)0;

LAB18:    t1 = t7;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(1999, ng0);
    t4 = (t0 + 51752);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(2001, ng0);
    t2 = (t0 + 13560U);
    t10 = *((char **)t2);
    t18 = *((unsigned char *)t10);
    t19 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t18);
    t2 = (t0 + 13720U);
    t13 = *((char **)t2);
    t20 = *((unsigned char *)t13);
    t21 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t19, t20);
    t2 = (t0 + 51752);
    t14 = (t2 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t22 = *((char **)t16);
    *((unsigned char *)t22) = t21;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t2 = (t0 + 4760U);
    t8 = *((char **)t2);
    t12 = *((unsigned char *)t8);
    t17 = (t12 == (unsigned char)3);
    t7 = t17;
    goto LAB18;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_69(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(2006, ng0);

LAB3:    t1 = (t0 + 20120U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 51816);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 45736);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_70(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(2028, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45752);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(2029, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)1);
    if (t6 == 1)
        goto LAB13;

LAB14:    t1 = (unsigned char)0;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(2034, ng0);
    t2 = (t0 + 51880);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(2030, ng0);
    t4 = (t0 + 51880);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(2032, ng0);
    t2 = (t0 + 51880);
    t8 = (t2 + 56U);
    t10 = *((char **)t8);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t2 = (t0 + 9720U);
    t5 = *((char **)t2);
    t7 = *((unsigned char *)t5);
    t9 = (t7 == (unsigned char)3);
    t1 = t9;
    goto LAB15;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_71(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    xsi_set_current_line(2039, ng0);

LAB3:    t1 = (t0 + 51944);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_72(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;

LAB0:    xsi_set_current_line(2061, ng0);
    t2 = (t0 + 1520U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 45768);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(2062, ng0);
    t4 = (t0 + 1720U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 25216U);
    t10 = *((char **)t4);
    t11 = *((unsigned char *)t10);
    t12 = (t9 == t11);
    if (t12 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 8440U);
    t4 = *((char **)t2);
    t7 = *((unsigned char *)t4);
    t9 = (t7 == (unsigned char)1);
    if (t9 == 1)
        goto LAB19;

LAB20:    t6 = (unsigned char)0;

LAB21:    if (t6 == 1)
        goto LAB16;

LAB17:    t2 = (t0 + 8440U);
    t8 = *((char **)t2);
    t18 = *((unsigned char *)t8);
    t19 = (t18 == (unsigned char)3);
    if (t19 == 1)
        goto LAB22;

LAB23:    t17 = (unsigned char)0;

LAB24:    t3 = t17;

LAB18:    if (t3 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 8440U);
    t13 = *((char **)t2);
    t23 = *((unsigned char *)t13);
    t24 = (t23 == (unsigned char)5);
    if (t24 == 1)
        goto LAB25;

LAB26:    t22 = (unsigned char)0;

LAB27:    t1 = t22;

LAB15:    if (t1 != 0)
        goto LAB11;

LAB12:    xsi_set_current_line(2069, ng0);
    t2 = (t0 + 52008);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1560U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(2063, ng0);
    t4 = (t0 + 52008);
    t13 = (t4 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

LAB11:    xsi_set_current_line(2067, ng0);
    t2 = (t0 + 52008);
    t15 = (t2 + 56U);
    t16 = *((char **)t15);
    t27 = (t16 + 56U);
    t28 = *((char **)t27);
    *((unsigned char *)t28) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB13:    t1 = (unsigned char)1;
    goto LAB15;

LAB16:    t3 = (unsigned char)1;
    goto LAB18;

LAB19:    t2 = (t0 + 9880U);
    t5 = *((char **)t2);
    t11 = *((unsigned char *)t5);
    t12 = (t11 == (unsigned char)3);
    t6 = t12;
    goto LAB21;

LAB22:    t2 = (t0 + 9880U);
    t10 = *((char **)t2);
    t20 = *((unsigned char *)t10);
    t21 = (t20 == (unsigned char)3);
    t17 = t21;
    goto LAB24;

LAB25:    t2 = (t0 + 9880U);
    t14 = *((char **)t2);
    t25 = *((unsigned char *)t14);
    t26 = (t25 == (unsigned char)3);
    t22 = t26;
    goto LAB27;

}

static void axi_iic_v1_02_a_a_0123855902_1516540902_p_73(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    char *t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;

LAB0:    xsi_set_current_line(2074, ng0);
    t5 = (t0 + 8440U);
    t6 = *((char **)t5);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)0);
    if (t8 == 1)
        goto LAB14;

LAB15:    t5 = (t0 + 8440U);
    t9 = *((char **)t5);
    t10 = *((unsigned char *)t9);
    t11 = (t10 == (unsigned char)2);
    t4 = t11;

LAB16:    if (t4 == 1)
        goto LAB11;

LAB12:    t5 = (t0 + 8440U);
    t12 = *((char **)t5);
    t13 = *((unsigned char *)t12);
    t14 = (t13 == (unsigned char)4);
    t3 = t14;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t5 = (t0 + 8440U);
    t15 = *((char **)t5);
    t16 = *((unsigned char *)t15);
    t17 = (t16 == (unsigned char)6);
    t2 = t17;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t5 = (t0 + 15320U);
    t18 = *((char **)t5);
    t19 = *((unsigned char *)t18);
    t20 = (t19 == (unsigned char)3);
    t1 = t20;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB17:    t25 = (t0 + 52072);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    *((unsigned char *)t29) = (unsigned char)2;
    xsi_driver_first_trans_fast(t25);

LAB2:    t30 = (t0 + 45784);
    *((int *)t30) = 1;

LAB1:    return;
LAB3:    t5 = (t0 + 52072);
    t21 = (t5 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)3;
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t2 = (unsigned char)1;
    goto LAB10;

LAB11:    t3 = (unsigned char)1;
    goto LAB13;

LAB14:    t4 = (unsigned char)1;
    goto LAB16;

LAB18:    goto LAB2;

}


extern void axi_iic_v1_02_a_a_0123855902_1516540902_init()
{
	static char *pe[] = {(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_0,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_1,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_2,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_3,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_4,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_5,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_6,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_7,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_8,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_9,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_10,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_11,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_12,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_13,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_14,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_15,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_16,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_17,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_18,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_19,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_20,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_21,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_22,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_23,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_24,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_25,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_26,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_27,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_28,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_29,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_30,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_31,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_32,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_33,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_34,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_35,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_36,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_37,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_38,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_39,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_40,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_41,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_42,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_43,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_44,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_45,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_46,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_47,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_48,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_49,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_50,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_51,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_52,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_53,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_54,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_55,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_56,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_57,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_58,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_59,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_60,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_61,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_62,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_63,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_64,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_65,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_66,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_67,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_68,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_69,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_70,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_71,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_72,(void *)axi_iic_v1_02_a_a_0123855902_1516540902_p_73};
	xsi_register_didat("axi_iic_v1_02_a_a_0123855902_1516540902", "isim/module_1_stub.exe.sim/axi_iic_v1_02_a/a_0123855902_1516540902.didat");
	xsi_register_executes(pe);
}
