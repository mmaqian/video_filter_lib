/*****************************************************************************
* Filename:          C:\Xilinx\hdmi_pass_thr\hdmi_pass_thr\hdmi_pass_thr.srcs\sources_1\edk\module_1/drivers/simple_register_v1_00_a/src/simple_register.c
* Version:           1.00.a
* Description:       simple_register Driver Source File
* Date:              Mon Apr 28 14:07:31 2014 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "simple_register.h"

/************************** Function Definitions ***************************/

