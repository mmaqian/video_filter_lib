/*****************************************************************************
* Filename:          C:\Xilinx\hdmi_pass_thr\hdmi_pass_thr\hdmi_pass_thr.srcs\sources_1\edk\module_1/drivers/simple_register_v1_00_a/src/simple_register.c
* Version:           1.00.a
* Description:       simple_register Driver Source File
* Date:              Mon Apr 28 14:07:31 2014 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "simple_register.h"
#include "xparameters.h"


/************************** Function Definitions ***************************/
int filter_ip_bypass_mode(int bypass_mode) {
    SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG31_OFFSET,0x0);
    usleep(100);

    if (bypass_mode == 0) {
        xil_printf( "Switched to functional mode ...\n\r" );
    	SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG0_OFFSET,0xF);
    } else {
        xil_printf( "Switched to bypass mode ...\n\r" );
        SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG0_OFFSET,0x1);
    }
    SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG31_OFFSET,0x1);

    usleep(100);
    return 0;
}

int filter_ip_set_resolution(Xuint32 hdmio_width,Xuint32 hdmio_height) {
    //Program the source resolution
    // 16 LSB = horz res
    // 16 MSB = vert res
	int vid_res = (hdmio_height << 16) + hdmio_width;
    printf("resolution is %x ...\r\n", vid_res);

	SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG31_OFFSET,0x0);
    usleep(100);

    SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG2_OFFSET,vid_res);

    SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG31_OFFSET,0x1);
    usleep(100);
    return 0;
}

int filter_ip_set_coef(int coef[9],int shift_factor) {
	int write_value;
	int i;

    SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG31_OFFSET,0);
    usleep(100);

    for (i=0;i<9;i++) {
        write_value = coef[i] << shift_factor;
        SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,12+4*i,write_value);
    }

    SIMPLE_REGISTER_mWriteReg(SIMPLE_REGISTER_BASE_ADDRESS,SIMPLE_REGISTER_SLV_REG31_OFFSET,0x1);
    usleep(100);
    return 0;
}

int original () {
	int coef[9] = {0,0,0,0,1,0,0,0,0};
	int shift_factor = 5;
	filter_ip_set_coef(coef,shift_factor);
	return 0;
}

int sharpen (int scale_factor) {
	int coef[9] = {0,-1,0,-1,5,-1,0,-1,0};
	int shift_factor = scale_factor;
	filter_ip_set_coef(coef,shift_factor);
	return 0;
}

int edgeDetection(int scale_factor) {
	int coef0[9] = { 1, 0,-1, 0, 0, 0,-1, 0, 1};
	int coef1[9] = { 0, 1, 0, 1,-4, 1, 0, 1, 0};
	int coef2[9] = {-1,-1,-1,-1, 8,-1,-1,-1,-1};
	int shift_factor;
	switch (scale_factor) {
		case 1 :
			shift_factor = 4;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 2 :
			shift_factor = 5;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 3 :
			shift_factor = 6;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 4 :
			shift_factor = 4;
			filter_ip_set_coef(coef1,shift_factor);
		break;
		case 5 :
			shift_factor = 5;
			filter_ip_set_coef(coef1,shift_factor);
		break;
		case 6 :
			shift_factor = 6;
			filter_ip_set_coef(coef1,shift_factor);
		break;
		case 7 :
			shift_factor = 4;
			filter_ip_set_coef(coef2,shift_factor);
		break;
		case 8 :
			shift_factor = 5;
			filter_ip_set_coef(coef2,shift_factor);
		break;
		case 9 :
			shift_factor = 6;
			filter_ip_set_coef(coef2,shift_factor);
		break;
		default :
			shift_factor = 5;
			filter_ip_set_coef(coef1,shift_factor);
		break;
	}
	return 0;
}

int blur (int scale_factor) {
	int coef3[9] = {0,1,0,1,0,1,0,1,0}; // x4
	int coef2[9] = {1,1,1,1,0,1,1,1,1};	// x8
	int coef1[9] = {1,2,1,2,4,2,1,2,1}; // x16
	int coef0[9] = {1,4,1,4,12,4,1,4,1};  // x32
	int shift_factor;
	switch (scale_factor) {
		case 1 :
			shift_factor = 0;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 2 :
			shift_factor = 0;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 3 :
			shift_factor = 0;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 4 :
			shift_factor = 0;
			filter_ip_set_coef(coef0,shift_factor);
		break;
		case 5 :
			shift_factor = 1;
			filter_ip_set_coef(coef1,shift_factor);
		break;
		case 6 :
			shift_factor = 2;
			filter_ip_set_coef(coef2,shift_factor);
		break;
		case 7 :
			shift_factor = 3;
			filter_ip_set_coef(coef3,shift_factor);
		break;
		case 8 :
			shift_factor = 3;
			filter_ip_set_coef(coef3,shift_factor);
		break;
		case 9 :
			shift_factor = 3;
			filter_ip_set_coef(coef3,shift_factor);
		break;
	}
	return 0;
}
